﻿--[[
    Name:           SDDuelDecline
	Description:	Intuitive multi-level response duel decline addon.
	Author:         Suddendeath2000
	Version:        v3.3.5
    --]]
 
SDDDVersion = "3.3.5"
SDDDColor1 = "|cff33ff00"  --System Green--
SDDDColor2 = "|cffff0000"  --System Red--
SDDDColor3 = "|cffffffff"  --System White--
SDDDColor4 = "|cffffcc00"  --System Gold--
SDDDColor5 = "|cff33cc33"  --Name Green--
SDDDTempName = "SDDDTempNameT0Test"
SDDDName = nil
SDDDBlocking = false
SDDDBlockName = nil
SDDDBlockTime = nil

function SDDuelDecline_OnLoad(panel)
    DEFAULT_CHAT_FRAME:AddMessage(SDDDColor5..SDDDID..SDDDColor3.." v"..SDDDColor5..SDDDVersion.." "..SDDDColor3..SDDDBY.."|cff999999|cff999999Suddendeath2000")
       
    this:RegisterEvent("DUEL_REQUESTED", arg1)
    this:RegisterEvent("DUEL_FINISHED")    
    this:RegisterEvent("CHAT_MSG_WHISPER", arg1, arg2)
    this:RegisterEvent("CHAT_MSG_WHISPER_INFORM", arg1)
    this:RegisterEvent("ADDON_LOADED")
    this:RegisterEvent("PLAYER_LOGOUT")
    
    ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER_INFORM", SDDDDuelDecline_AddFilter)    
    ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", SDDDDuelDecline2_AddFilter)
  
end

function SDDuelDeclineOptionsFrame_OnLoad(panel) 
    panel.name = SDDDID
    panel.okay = function (self) SDDuelDeclinePanel_Close() end
    panel.cancel = function (self)  SDDuelDeclinePanel_CancelOrLoad() end   
    panel.default = function (self)  SDDuelDeclinePanel_Default() end
    InterfaceOptions_AddCategory(panel)
end

function SDDuelDecline_OnEvent(event, arg1, arg2)
    if event == "CHAT_MSG_WHISPER" and arg2 == SDDDBlockName and SDDDBlocking == true then
      SDDDBlockMes = arg1      
      SendChatMessage(SDDDBLOCKED, "WHISPER" ,_ ,SDDDBlockName)
  end
    
    if event == "ADDON_LOADED" and arg1 == SDDDID then
      if SDDDShown == nil or (not SDDDShown) then UIErrorsFrame:AddMessage(SDDDColor4..SDDDID.."\r-------------\r"..SDDDColor3..SDDDINITIAL, 30); SDDDShown = 1                                                  
  end 
      if SDDDToggleOver == nil then
        SDDDToggle = true
        SDDDAutoReport = true
        SDDDAutoBlock = true
        SDDDAutoHide = true
        SDDDBlockLength = 300
        SDDDWhisp1 = SDDDWHISP1
        else
          SDDDToggle = SDDDToggleOver
          SDDDAutoReport = SDDDAutoReportOver
          SDDDAutoBlock = SDDDAutoBlockOver
          SDDDAutoHide = SDDDAutoHideOver   
          SDDDBlockLength = SDDDBlockLengthOver
          SDDDWhisp1 = SDDDWhisp1Over
    end    
  end

    if event == "DUEL_REQUESTED" and (not IsShiftKeyDown()) and SDDDToggle == true then
      SDDDName = arg1     
      HideUIPanel(StaticPopup1)
      if SDDDTempName:match(SDDDName) then SDDDDeclined = SDDDDeclined + 1    
        else SDDDTempName = SDDDName
             SDDDDeclined = 0
  end
      if SDDDDeclined == 0 then       
        CancelDuel()        
        SendChatMessage(SDDDWHISP1, "WHISPER" ,_ ,SDDDName)     
        elseif SDDDDeclined == 1 then         
          CancelDuel()        
          SendChatMessage(SDDDName..SDDDWHISP2, "WHISPER" ,_ ,SDDDName)
          elseif SDDDDeclined == 2 then           
            SendChatMessage(SDDDWHISP3, "WHISPER" ,_ ,SDDDName)
            SDDuelDecline_WhispBlock()
            elseif SDDDDeclined == 3 then             
              SendChatMessage(SDDDWHISP4, "WHISPER" ,_ ,SDDDName)
              SDDuelDecline_WhispBlock()
              elseif SDDDDeclined == 4 then               
                SDDDDDuelDecline_Report()                
                SDDuelDecline_WhispBlock()
                elseif SDDDDeclined == 5 then                 
                  AddIgnore(SDDDName)
                  SendChatMessage(SDDDWHISP7, "WHISPER" ,_ ,SDDDName)
                  elseif SDDDDeclined >= 6 then
                    SDDuelDecline_WhispBlock()
    end
  end
  
    if event == "DUEL_FINISHED" then UIErrorsFrame:Clear()  
  end
  
    if event == "PLAYER_LOGOUT" then 
      SDDDToggleOver = SDDDToggle
      SDDDAutoBlockOver = SDDDAutoBlock
      SDDDAutoReportOver = SDDDAutoReport
      SDDDAutoHideOver = SDDDAutoHide
      SDDDBlockLengthOver = SDDDBlockLength
      SDDDWhisp1Over = SDDDWhisp1
  end    
end

function SDDDDDuelDecline_Report()
    if SDDDAutoReport == true then
      ComplainChat(SDDDName, SDDDCOMPLAIN)
      SendChatMessage(SDDDName..SDDDWHISP5, "WHISPER" ,_ ,SDDDName)      
      else SDDDNameLabel:SetText(SDDName)
           SDDuelDeclineReport:Show()
  end
end

function SDDDDuelDecline_ManualReport()    
    if SDDDName then
      ComplainChat(SDDDName, SDDDCOMPLAIN)
      SendChatMessage(SDDDName..SDDDWHISP5, "WHISPER" ,_ ,SDDDName)
      ChatFrame1:AddMessage(SDDDColor4..SDDDID"..: "..SDDDName..SDDDRS)
      SDDuelDeclineReport:Hide() 
      else SDDuelDeclineReport:Hide() 
  end
end

function SDDDDuelDecline_Merciful()
    if SDDDName then
      SendChatMessage(SDDDName..SDDDWHISP6, "WHISPER" ,_ ,SDDDName)
      SDDuelDeclineReport:Hide() 
      else SDDuelDeclineReport:Hide() 
  end
end

function SDDuelDeclinePanel_Default()
    SDDDToggle = true
    SDDDAutoReport = true
    SDDDAutoBlock = true
    SDDDAutoHide = true
    SDDDBlockLength = 300
    SDDDWhisp1 = SDDDWHISP1
    InterfaceOptionsFrame:Hide()
    InterfaceOptionsFrame:Show()
    GameMenuFrame:Hide()
end

function SDDDDuelDecline_AddFilter(ChatFrame, event, ...)
    if SDDDAutoHide == true then
      if strfind(arg1, SDDDWHISP1) or 
        strfind(arg1, SDDDWHISP2) or   
        strfind(arg1, SDDDWHISP3) or
        strfind(arg1, SDDDWHISP4) or
        strfind(arg1, SDDDWHISP5) or
        strfind(arg1, SDDDWHISP6) or
        strfind(arg1, SDDDBLOCKED) then          
        return true
    end
  end
end

function SDDDDuelDecline2_AddFilter(ChatFrame, event, ...)
    if (SDDDBlockMes) and SDDDAutoHide == true and strfind(arg1, SDDDBlockMes) then      
      return true
  end
    SDDDBlockMes = nil
end

function SDDuelDecline_WhispBlock()
    if SDDDAutoBlock == true then
      SDDDBlockName = SDDDName
      SDDDBlockTime = SDDDTime + SDDDBlockLength
  end
end

function SDDuelDecline_OnUpdate() 
    SDDDTime = GetTime()  
    SDDDBlockTimeXML = "    "..SDDDColor4..SDDDBTXML..SDDDColor3..SDDDBlockLength
    SDDDXMLBlockWhisp:SetText(SDDDBlockTimeXML) 
    if (SDDDBlockTime) and SDDDBlockTime > SDDDTime then SDDDBlocking = true
      else SDDDBlocking = false
           SDDDBlockName = nil
           SDDDBlockTime = nil
           SDDDDeclined = 0
   end
end