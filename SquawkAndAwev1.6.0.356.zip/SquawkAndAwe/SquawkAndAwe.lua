--[[

Version 1.6.0

Author : Adoriele of US Dragonblight - with permission from Levva of EU Khadgar

Repurposed version of ShockAndAwe, an Enhancement Shaman addon, for Balance
	Druids. Provides Debuff timers, as well as proc and cooldown bars for Eclipse
	and Omen of Clarity.

Changelog:

v1.6.0	- Added support for Custom Bars. Instructions are in CustomBars.lua. 
			Fixed a bug that was preventing Languish ticks from showing. Added
			Disable/Enable commands, access using "/saa enable" or "/saa disbale".
			Added sounds for abilities coming off cooldown. Added ability to force
			SAA to grow upwards. Really, it just flips SAA over.

v1.5.1	- Added bars for Tier 9 and 10 idols and Languish. Added a toggle to tell SAA that you 
			only have one Trinket. When checked, SAA will only allocate space for a single trinket
			bar. A second trinket buff detected will collide with the first Proc bar. When unchecked,
			the first buff detected will show just above the Proc bars. The second will appear on top.
			Added support for a short trinket name. Added support for controlling order of bars within
			categories.
			

v1.5.0	- 3.3.3 patch compatability fix. Added support for Omen of Doom procs and proc sounds.
			Proc sounds are enabled globally with a new checkbox in the Procs tab, procs can 
			individaully select sounds with a new drop-down in each proc's tab. Fixed a couple
			other minor errors as well. Known issue: sometimes after changing bar options, some 
			bars may become transparent (though still functional). Reloading the UI will fix this.

v1.4.1	- Eclipse cooldown no longer constantly refreshes to 30s, added eclipse type to Eclipse
			cooldown bars, changed functionality of Eclipse buff bar to go grey if
			the buff disappears early
v1.4.0	- 3.3 patch workaround for lack of Eclipse in Combat Log
v1.3.3  - Fixed bug causing debuffs not to spawn when switching targets. Fixed
			bug involving disabling a bar that's currently active.
v1.3.2  - Oops: Applied Debuff/CC change to Abilities as well, and to be safe did
			similar things to Procs and Trinkets as a double-check. Also fixed a
			bug that would not let you turn off the Eclipse bar.
v1.3.1	- Fixed "Debuff/CC, a nil value" bug
v1.3	- Serious revamp of underlying mechanics. Added trinket bars, cc bars,
			multiple proc bars. Added ability to merge bars of the same type
			(except procs). Adding custom bars should now be much easier,
			relatively.
v1.2.1	- Fixed bug with Eclipse and Moonfire bars overlapping, changed FF bar
			to accept any FF.
v1.2	- 3.1 Compatability
v1.1.1	- Fixed GCD bar to be localization independent, added SF Combo points,
			structural changes
v1.1	- Finally fixed OoC issue, removed dependency on localization for
			functionality
v1.0.5	- Fixed encoding issue with Russian locale, added German locale
v1.0.4	- Fixed a bug with the French localization, added Russian and Taiwan
V1.0.3	- Fixed a bug with the OoC bar
V1.0.2	- Added French localization, fixed test bar bug
V1.0.1	- Added text and icon options

--]]

-- Basic Ace3 stuff
local L = LibStub("AceLocale-3.0"):GetLocale("SquawkAndAwe")
local AceAddon = LibStub("AceAddon-3.0")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
SquawkAndAwe = AceAddon:NewAddon("SquawkAndAwe", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
local REVISION = tonumber(("$Revision: 1.6.0 $"):match("%d+"))

-- Frame creation
SquawkAndAwe.frames = {}
SquawkAndAwe.BaseFrame = CreateFrame("Frame","SquawkAndAweBase",UIParent)

-- Other initializations
SquawkAndAwe.textures = {}
SquawkAndAwe.borders = {}
SquawkAndAwe.fonts = {}
SquawkAndAwe.sounds = {}
SquawkAndAwe.barBackdrop = {
		bgFile = "Interface/Tooltips/UI-Tooltip-Background",
		edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
		tile = false, tileSize = 0, edgeSize = 12,
		insets = { left = 2, right = 2, top = 2, bottom = 2 }
	}
SquawkAndAwe.frameBackdrop ={
		bgFile = "Interface/Tooltips/UI-Tooltip-Background",
		--edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
		tile = false, tileSize = 0, edgeSize = 12,
		insets = { left = 0, right = 0, top = 0, bottom = 0 }
	}

SquawkAndAwe.combat = {}
SquawkAndAwe.combat.procs = {}
SquawkAndAwe.combat.procs.Eclipse	= {id = 48518,	name = GetSpellInfo(48518),	cd = 30}
SquawkAndAwe.combat.procs.Eclipsew	= {id = 48517,	name = GetSpellInfo(48517),	cd = 30}
SquawkAndAwe.combat.procs.Omen		= {id = 16870,	name = GetSpellInfo(16870)}
SquawkAndAwe.combat.procs.T84P		= {id = 64823,	name = GetSpellInfo(64823)}
SquawkAndAwe.combat.procs.T102P		= {id = 70721,	name = GetSpellInfo(70721)}
SquawkAndAwe.combat.procs.PVP		= {id = 46833,	name = GetSpellInfo(46833)}
SquawkAndAwe.combat.procs.Idol10	= {id = 71177, name = GetSpellInfo(71177)}
SquawkAndAwe.combat.procs.Idol9		= {id = 67360, name = GetSpellInfo(67360)}
SquawkAndAwe.combat.debuffs = {}
SquawkAndAwe.combat.debuffs.Moonfire	= {id = 8921,	name = GetSpellInfo(8921),	tick = 3}
SquawkAndAwe.combat.debuffs.Insect		= {id = 5570,	name = GetSpellInfo(5570),	tick = 2}
SquawkAndAwe.combat.debuffs.Faerie		= {id = 770,	name = GetSpellInfo(770)}
SquawkAndAwe.combat.debuffs.Languish	= {id = 71023,	name = GetSpellInfo(71023), tick = 2}
SquawkAndAwe.combat.cc = {}
SquawkAndAwe.combat.cc.Roots		= {id = 339,	name = GetSpellInfo(339)}
SquawkAndAwe.combat.cc.Hibernate	= {id = 2637,	name = GetSpellInfo(2637)}
SquawkAndAwe.combat.cc.Cyclone		= {id = 33786,	name = GetSpellInfo(33786)}
SquawkAndAwe.combat.abilities = {}
SquawkAndAwe.combat.abilities.Innervate		= {id = 29166,	name = GetSpellInfo(29166)}
SquawkAndAwe.combat.abilities.Force			= {id = 33831,	name = GetSpellInfo(33831),	dur = 30}
SquawkAndAwe.combat.abilities.Starfall		= {id = 48505,	name = GetSpellInfo(48505)}
SquawkAndAwe.combat.abilities.Typhoon		= {id = 50516,	name = GetSpellInfo(50516)}
SquawkAndAwe.combat.abilities.Barkskin		= {id = 22812,	name = GetSpellInfo(22812)}
SquawkAndAwe.combat.trinkets = {}
SquawkAndAwe.combat.trinkets.flare				= {id = 64713,	itemid = 45518,	name = GetSpellInfo(64713), itemname	= GetItemInfo(45518),	color = {r=1, g=0.8, b=0.32, a=0.9},	cd = 45}
SquawkAndAwe.combat.trinkets.flame				= {id = 64712,	itemid = 45148,	name = GetSpellInfo(64712), itemname	= GetItemInfo(45148),	color = {r=1, g=0.42, b=0, a=0.9}}
SquawkAndAwe.combat.trinkets.pandora			= {id = 64741,	itemid = 45490,	name = GetSpellInfo(64741), itemname	= GetItemInfo(45490),	color = {r=0.13, g=1, b=0.35, a=0.9},	cd = 45}
SquawkAndAwe.combat.trinkets.fates				= {id = 64707,	itemid = 45466,	name = GetSpellInfo(64707), itemname	= GetItemInfo(45466),	color = {r=0.16, g=1, b=0.69, a=0.9}}
SquawkAndAwe.combat.trinkets.focus				= {id = 65004,	itemid = 45866,	name = GetSpellInfo(65004), itemname	= GetItemInfo(45866),	color = {r=0.46, g=0.38, b=1, a=0.9},	cd = 45}
SquawkAndAwe.combat.trinkets.siphon				= {id = 65008,	itemid = 45292,	name = GetSpellInfo(65008), itemname	= GetItemInfo(45292),	color = {r=0.5, g=0, b=1, a=0.9}}
SquawkAndAwe.combat.trinkets.broodmother		= {id = 65006,	itemid = 45308,	name = GetSpellInfo(65006), itemname	= GetItemInfo(45308),	color = {r=0, g=1, b=0.3, a=0.9},	cd = 0}
SquawkAndAwe.combat.trinkets.dying				= {id = 60494,	itemid = 40255,	name = GetSpellInfo(60494), itemname	= GetItemInfo(40255),	color = {r=0, g=0.37, b=0.12, a=0.9},	cd = 45}
SquawkAndAwe.combat.trinkets.illustration		= {id = 60486,	itemid = 40432,	name = GetSpellInfo(60486), itemname	= GetItemInfo(40432),	color = {r=0.75, g=0.30, b=0.65, a=0.9},	cd = 0}
SquawkAndAwe.combat.trinkets.spider				= {id = 60492,	itemid = 39229,	name = GetSpellInfo(60492), itemname	= GetItemInfo(39229),	color = {r=0.62, g=0.27, b=0.18, a=0.9},	cd = 45}
SquawkAndAwe.combat.trinkets.sundial			= {id = 60064,	itemid = 40682,	name = GetSpellInfo(60064), itemname	= GetItemInfo(40682),	color = {r=0.16, g=0.93, b=0.91, a=0.9},	cd = 45}
SquawkAndAwe.combat.trinkets.serpent			= {id = 56184,	itemid = 42395,	name = GetSpellInfo(56184), itemname	= GetItemInfo(42395),	color = {r=0.2, g=0.02, b=0.48, a=0.9}}
SquawkAndAwe.combat.trinkets.ember				= {id = 60479,	itemid = 37660,	name = GetSpellInfo(60479), itemname	= GetItemInfo(37660),	color = {r=1, g=0.04, b=0.09, a=0.9},	cd = 45}
SquawkAndAwe.combat.trinkets.prisoner			= {id = 60480,	itemid = 37873,	name = GetSpellInfo(60480), itemname	= GetItemInfo(37873),	color = {r=0.51, g=0.47, b=0.50, a=0.9}}
SquawkAndAwe.combat.trinkets.winged				= {id = 60521,	itemid = 37844,	name = GetSpellInfo(60521), itemname	= GetItemInfo(37844),	color = {r=1, g=0.35, b=0.73, a=0.9}}
SquawkAndAwe.combat.trinkets.tome				= {id = 60471,	itemid = 36972,	name = GetSpellInfo(60471), itemname	= GetItemInfo(36972),	color = {r=0.84, g=0.6, b=0.15, a=0.9}}
SquawkAndAwe.combat.trinkets.Phylactery			= {id = 71605,	itemid = 50360, name = GetSpellInfo(71605), itemname	= GetItemInfo(50360),	color = {r=0, g=0.37, b=0.12, a=0.9}, cd = 100, shortname = "Phylactery"}
SquawkAndAwe.combat.trinkets.HeroicPhylactery	= {id = 71636,	itemid = 50365, name = GetSpellInfo(71636), itemname	= GetItemInfo(50365),	color = {r=0, g=0.37, b=0.12, a=0.9}, cd = 100, shortname = "Phylactery"}
SquawkAndAwe.combat.trinkets.Spyglass			= {id = 71570,	itemid = 50340, name = GetSpellInfo(71570), itemname	= GetItemInfo(50340),	color = {r=0, g=0.37, b=0.12, a=0.9}, cd = 0}
SquawkAndAwe.combat.trinkets.HeroicSpyglass		= {id = 71572,	itemid = 50345, name = GetSpellInfo(71572), itemname	= GetItemInfo(50345),	color = {r=0, g=0.37, b=0.12, a=0.9}, cd = 0}
SquawkAndAwe.combat.trinkets.DFO				= {id = 71601,	itemid = 50353, name = GetSpellInfo(71601), itemname	= GetItemInfo(50353),	color = {r=0, g=0.37, b=0.12, a=0.9}, cd = 45, shortname = "DFO"}
SquawkAndAwe.combat.trinkets.HeroicDFO			= {id = 71644,	itemid = 50348, name = GetSpellInfo(71644), itemname	= GetItemInfo(50348),	color = {r=0, g=0.37, b=0.12, a=0.9}, cd = 45, shortname = "DFO"}
SquawkAndAwe.combat.Moonglade	= {id = 18960,	name = GetSpellInfo(18960)}
SquawkAndAwe.combat.Starfire	= {id = 2912,	name = GetSpellInfo(2912)}
SquawkAndAwe.combat.Wrath		= {id = 5176,	name = GetSpellInfo(5176)}
SquawkAndAwe.combat.FeralFF		= {id = 16857, name = GetSpellInfo(16857)}

SquawkAndAwe.actives	= {}
SquawkAndAwe.actives.trinkets 	= {}
SquawkAndAwe.actives.procs		= {}
SquawkAndAwe.actives.cc			= {}
SquawkAndAwe.actives.debuffs	= {}
SquawkAndAwe.actives.abilities	= {}
SquawkAndAwe.ActiveEclipseBuff = false

SquawkAndAwe.activeTrinketNames = {}
SquawkAndAwe.activeTrinketNames.Trinket1 = "flare"
SquawkAndAwe.activeTrinketNames.Trinket2 = "flame"

SquawkAndAwe.times	= {}

SquawkAndAwe.barFrames			= {}
local barFrameIndex 	= 0
SquawkAndAwe.statusBars 		= {}
local statusbarIndex    = 0

local playerName	= UnitName("player");
local LastMF		= 0
local SFCombos		= 0


-------------------
-- Config details
-------------------

SquawkAndAwe.defaults = {
	char = {
		-- Settings
		-- Frame
		fWidth		= 300,
		barHeight	= 25,
		scale		= 1,

		-- Bars
		bars = {
			-- Maximum bar length in time
			MaxLen			= 30,
			autoorder		= false,
			growup			= false,
			
			-- Trinkets
			trinketshow		= false,
			mergetrinkets	= true,
			trinketcd		= false,
			singletrinket	= false,
			
			-- Procs
			cdcolor	= {r=0.6,	g=0.6,	b=0.6,	a=0.9},
			procs	= {
				sounds	= true,
				Eclipse	= {
					show		= true,
					color		= {r=1,		g=1, 	b=1, 	a=0.9},
					sound		= "None",
					cd			= true,
					flash   	= true,
					order		= 1,
				},
				Eclipsew	= {
					color	= {r=0,		g=1, 	b=0, 	a=0.9},
					sound	= "None",
				},
				Omen		= {
					show	= true,
					color	= {r=0.6,	g=0.6,	b=1,	a=0.9},
					sound	= "None",
					flash   = false,
					order	= 2,
				},
				T84P		= {
					show	= true,
					color	= {r=0.43,		g=0.61,	b=1,	a=0.9},
					sound	= "None",
					flash   = true,
					order	= 3,
				},
				T102P		= {
					show	= true,
					color	= {r=0.8,	g=0.2, 	b=0.4,	a=0.9},
					sound	= "None",
					flash	= true,
					order	= 4,
				},
				PVP		= {
					show	= false,
					color	= {r=0.54,		g=0.32,	b=1,	a=0.9},
					sound	= "None",
					flash   = true,
					order	= 5,
				},
				Idol9	= {
					show	= false,
					color	= {r=1, g=0, b=1, a=0.9},
					sound	= "None",
					flash	= false,
					order	= 6,
				},
				Idol10	= {
					show	= true,
					color	= {r=0, g=0.5, b=1, a=0.9},
					sound	= "None",
					flash	= false,
					order	= 6,
				},
			},
			
			-- Debuffs
			mergedebuffs	= false,
			tickcolor		= {r=0.6,	g=0.6,	b=0.6,	a=0.9},
			debuffs	= {
				Moonfire	= {
					show	= true,
					color	= {r=0.5,	g=0,	b=1,	a=0.9},
					tick	= true,
					order	= 1,
				},
				Insect	= {
					show	= true,
					color	= {r=0,		g=1,	b=0.3,	a=0.9},
					tick	= true,
					order	= 2,
				},
				Faerie	= {
					show 	= true,
					color	= {r=1,		g=0.5,	b=1,	a=0.9},
					order	= 4,
				},
				Languish	={
					show	= true,
					color	= {r=0.38, g=0.2, b=0.08, a=0.9},
					order	= 3,
				},
			} ,
			
			-- CC
			mergecc			= true,
			cc	= {
				Roots		= {
					show	= true,
					color	= {r=0.38,		g=0.2,	b=0.08,	a=0.9},
					order	= 1,
				},
				Hibernate	= {
					show	= true,
					color	= {r=1,		g=0.55,	b=0.54,	a=0.9},
					order	= 2,
				},
				Cyclone		= {
					show	= true,
					color	= {r=0.25,		g=0.25,	b=0.25,	a=0.9},
					order	= 3,
				},
			},
			
			-- Abilities
			mergeabilities	= true,
			abilities	= {
				Starfall		= {
					show	= true,
					color	= {r=1,		g=1,	b=1,	a=0.9},
					sound	= "None",
					dur		= true,
					order	= 1,
				},
				Typhoon		= {
					show	= true,
					color	= {r=0.5,		g=0,	b=1,	a=0.9},
					sound	= "None",
					order	= 2,
				},
				Force			= {
					show	= true,
					color	= {r=0,		g=1,	b=0,	a=0.9},
					sound	= "None",
					dur	= true,
					order	= 3,
				},
				Innervate	= {
					show	= true,
					color	= {r=0,		g=0,	b=1,	a=0.9},
					sound	= "None",
					dur	= true,
					order	= 4,
				},
				Barkskin		= {
					show	= true,
					color	= {r=1,		g=1,	b=0,	a=0.9},
					sound	= "None",
					dur	= true,
					order	= 5,
				},
			},
			
			GCD	=	{
				show	= true,
				color	= {r=0.6,	g=0.6,	b=0.6,	a=0.6},
			},
		},

		-- Media
		texture			= "BantoBar",
		border			= "None",
		barborder		= "None",
		icons				= true,
			-- Text
			barstext		= true,
			barfont		= "Friz Quadrata TT",
			barfontsize	= 12,
			spellnames	= true,
			durations	= true,
			sfcomboshow = true,

		-- Main
		debug	= false,
		barshow	= true,
		
		-- Incidentals
		relativeTo		= "UIParent",
		relativePoint	= "TOP",
		point			= "TOP",
		xOffset			= 0,
		yOffset			= 0,
		--fHeight			= 175,


		-- unused so far
		message	= "Welcome Home!",
		resetOn	= true,

	}
}

-----------------------------------------
-- Initialisation & Startup Routines
-----------------------------------------
-- Changed to hide uptime, stats, priority frames, kill options for now
function SquawkAndAwe:OnInitialize()
	local AceConfigReg = LibStub("AceConfigRegistry-3.0")
	local AceConfigDialog = LibStub("AceConfigDialog-3.0")
	
	self.db = LibStub("AceDB-3.0"):New("SquawkAndAweDBPC", SquawkAndAwe.defaults, "char")
	LibStub("AceConfig-3.0"):RegisterOptionsTable("SquawkAndAwe", self:GetOptions(), {"SquawkAndAwe", "saa"} )
	media.RegisterCallback(self, "LibSharedMedia_Registered")

	-- Add the options to blizzard frame (add them backwards so they show up in the proper order
	self.optionsFrame = AceConfigDialog:AddToBlizOptions("SquawkAndAwe","SquawkAndAwe")
	self.optionsFrame[L["About"]] = LibStub("LibAboutPanel").new("SquawkAndAwe", "SquawkAndAwe")
	self.db:RegisterDefaults(SquawkAndAwe.defaults)
	local version = GetAddOnMetadata("SquawkAndAwe","Version")
	self.version = ("SquawkAndAwe v%s (r%s)"):format(version, REVISION)
	self:Print(self.version.." Loaded.")
end

function SquawkAndAwe:OnDisable()
    -- Called when the addon is disabled
	self.BaseFrame:Hide()
	self:UnregisterEvent("PLAYER_ENTERING_WORLD")
	self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	self:UnregisterEvent("PLAYER_TARGET_CHANGED")
	self:UnregisterEvent("SPELL_UPDATE_COOLDOWN")
end

-- Unregistered a couple events, should work
function SquawkAndAwe:OnEnable()
	self:LibSharedMedia_Registered()
	self:RegisterEvent("PLAYER_ENTERING_WORLD")
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	self:RegisterEvent("PLAYER_TARGET_CHANGED")
	self:RegisterEvent("SPELL_UPDATE_COOLDOWN")
	--self:RegisterEvent("UNIT_AURA")
	self.BaseFrame:Show()
	self:RedrawFrames()
end

-- Should work without changes
function SquawkAndAwe:LibSharedMedia_Registered()
	for k, v in pairs(media:List("statusbar")) do
		self.textures[v] = v
	end
	for k, v in pairs(media:List("border")) do
		self.borders[v] = v
	end
	for k, v in pairs(media:List("font")) do
		self.fonts[v] = v
	end
	for k, v in pairs(media:List("sound")) do
		self.sounds[v] = v
	end
end

----------------------
-- Event Routines
----------------------
function SquawkAndAwe:PLAYER_ENTERING_WORLD()
	self:SetBorderTexture(nil, self.db.char.border)
	self:SetBarBorderTexture(nil, self.db.char.barborder)
	self:RedrawFrames()
end

--[[function SquawkAndAwe:UNIT_AURA(event,id)
	if id == "player" and not SquawkAndAwe.ActiveEclipseBuff then
		local _,_,_,_,_,_,_,_,_,_,spellID = UnitBuff("player",SquawkAndAwe.combat.procs.Eclipse.name);
		if spellID == SquawkAndAwe.combat.procs.Eclipse.id then
			SquawkAndAwe.ActiveEclipseBuff = true
			SquawkAndAwe:ProcBars("Eclipse", SquawkAndAwe.combat.procs.Eclipse)
		elseif spellID == SquawkAndAwe.combat.procs.Eclipsew.id then
			SquawkAndAwe.ActiveEclipseBuff = true
			SquawkAndAwe:ProcBars("Eclipsew", SquawkAndAwe.combat.procs.Eclipsew)
		end
	end -- if id == "player"
end -- function SAA:UNIT_AURA() --]]

function SquawkAndAwe:COMBAT_LOG_EVENT_UNFILTERED(_, timestamp, event, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, ...)
	local k,v,_,icon,color
	local spellID = select(1, ...)
	local spellName = select(2,...)
	if sourceGUID == UnitGUID("player") then
		if event == "SPELL_AURA_APPLIED" then
		    -- Trinket handler
			for k,v in pairs (SquawkAndAwe.combat.trinkets) do
				if spellID == v.id then
					if self.db.char.bars.trinketshow then
						SquawkAndAwe:TrinketBars(k,v)
					end -- if trinketshow
					return
				end -- if spellID == v.id
			end -- for k,v in pairs(trinkets)

			-- Proc handler
			for k,v in pairs(SquawkAndAwe.combat.procs) do
				if spellID == v.id then
					SquawkAndAwe:ProcBars(k,v)
					return
				end -- if spellID == v.id
			end -- for k,v in pairs(procs)

			-- Debuff Handler
			for k,v in pairs(SquawkAndAwe.combat.debuffs) do
				if spellName == v.name then
					if spellName == SquawkAndAwe.combat.debuffs.Moonfire.name then
						SFCombos = 0
						LastMF = 0
					end
					SquawkAndAwe:DebuffBars(k,v)
				return
           		end -- if spellID == v.id
			end -- for k,v in pairs(debuffs)

			-- CC Handler
			for k,v in pairs(SquawkAndAwe.combat.cc) do
				if spellName == v.name then
					SquawkAndAwe:CCBars(k)
					return
				end
			end

		-- Check for IS, MF ticks, reset bars
		elseif event == "SPELL_PERIODIC_DAMAGE" and destName == UnitName("target")then
			if spellID == SquawkAndAwe.combat.debuffs.Moonfire.id then
				
			elseif spellID == SquawkAndAwe.combat.debuffs.Insect.id then
				if self.db.char.bars.debuffs.Insect.tick then
					SquawkAndAwe.times.InsectTick = GetTime() + SquawkAndAwe.combat.debuffs.Insect.tick
				end
			end
			for k,v in pairs(SquawkAndAwe.combat.debuffs) do
				if spellName == v.name then
					if v.tick then
						SquawkAndAwe.times[k.."Tick"] = GetTime() + v.tick
					end	
           		end -- if spellID == v.id
			end -- for k,v in pairs(debuffs)
		-- Check for spell casts for spells that generate them
		elseif event == "SPELL_CAST_SUCCESS" then
         -- Ability handler
			for k,v in pairs(SquawkAndAwe.combat.abilities) do
				if spellName == v.name then
				    SquawkAndAwe:AbilityBars(k,v)
				    return
				end
			end

			-- Debuff Handler
			for k,v in pairs(SquawkAndAwe.combat.debuffs) do
				if spellName == v.name then
				    if spellName == SquawkAndAwe.combat.debuffs.Moonfire.name then
						SFCombos = 0
						LastMF = 0
					end
					SquawkAndAwe:DebuffBars(k,v)
				return
           		end -- if spellID == v.id
			end -- for k,v in pairs(debuffs)
		end -- event == EVENT
	-- Add handling for FF from any source
	elseif (spellID == SquawkAndAwe.combat.debuffs.Faerie.id or spellID == SquawkAndAwe.combat.FeralFF.id) and destName == UnitName("target") and (event == "SPELL_CAST_SUCCESS" or event == "SPELL_AURA_APPLIED") then
		SquawkAndAwe:DebuffBars("Faerie", SquawkAndAwe.combat.debuffs.Faerie)
	end -- if sourceGUID == player
end

-- Triggers GCD bar
function SquawkAndAwe:SPELL_UPDATE_COOLDOWN()
	if self.db.char.bars.GCD.show then
		self:GCDBar()
	end
end

-- Changing targets should refresh CC and Debuff bars
function SquawkAndAwe:PLAYER_TARGET_CHANGED()
	SquawkAndAwe:TriggerDebuffs()
	SquawkAndAwe:TriggerCC()
end

---------------------------
-- Buff Info functions
---------------------------

-- Generic spell getter
function SquawkAndAwe:GetSpellInfo(spellName, spelltype)
	local index = 1
	if spelltype == "buff" then
		while UnitBuff("player", index) do
			local name, _, _, _, _, _, expires = UnitBuff("player", index)
			if name == spellName then
				return expires
			end
			index = index + 1
		end
		return 0
	elseif spelltype == "debuff" or spelltype == "cc" then
		while UnitDebuff("target", index) do
			local name, _, _, _, _, _, expires, source = UnitDebuff("target", index)
			if name == spellName and (source == "player" or spellName == self.combat.debuffs.Faerie.name or spellName == self.combat.FeralFF.name) then
				return expires
			end
			index = index + 1
		end
		if spelltype == "cc" then
			index = 1
			while UnitDebuff("focus", index) do
				local name, _, _, _, _, _, expires, source = UnitDebuff("focus", index)
				if name == spellName and source == "player" then
					return expires
				end
				index = index + 1
			end
		end
		return 0
	elseif spelltype == "cd" then
	    local start, duration, enable = GetSpellCooldown(spellName)
		return start + duration
	elseif spelltype == "item" then
	    local start, duration, enable = GetItemCooldown(spellName)
	    return start + duration
	end
end

---------------------------
-- functions
---------------------------
-- Alias for CreateBaseFrame()
function SquawkAndAwe:RedrawFrames()
	self:ClearActives()
	self:HideAllBars()
	self:SetBaseFrame()
end

-- Finds the number of bars which have been activated. Merged categories count
-- as one bar, no matter how many bars are active
function SquawkAndAwe:FindNumBars()
	local num	= 0
	local k,v

	-- Add trinket bars
	if self.db.char.bars.trinketshow and self.db.char.bars.mergetrinkets then
		num = num + 1
	elseif self.db.char.trinketshow then
		num = num + 2
	end
	local numtrinkets = num

	-- Add proc bars (checking for Eclipse CD bar, even if buff bar is disabled)
	local procs = {}
	local procorders = {}
	local numprocs = 0
	for k,v in pairs(self.db.char.bars.procs) do
		if not ((k == "Eclipsew") or (k == "sounds")) then
			if v.show or v.cd then
				numprocs = numprocs + 1
				procs[numprocs]	= k
				procorders[numprocs] = v.order
			end
		end
	end
	num = num + numprocs
	procs = SquawkAndAwe:SortByValue(procs, procorders)
	
	-- Check for any debuff bars
	local debuffs = {}
	local debufforders = {}
	local numdebuffs = 0
	for k,v in pairs(self.db.char.bars.debuffs) do
		if v.show then
			numdebuffs = numdebuffs + 1
			debuffs[numdebuffs]	= k
			debufforders[numdebuffs] = v.order
		end
	end
	if self.db.char.bars.mergedebuffs and not numdebuffs == 0 then
		num = num + 1	-- If merged, only add one bar, and only of any are enabled
	else
		num = num + numdebuffs
		debuffs	= SquawkAndAwe:SortByValue(debuffs, debufforders)
	end
	
	-- Check for cc bars
	local ccs = {}
	local ccorders = {}
	local numccs = 0
	for k,v in pairs(self.db.char.bars.cc) do
		if v.show then
			numccs = numccs + 1
			ccs[numccs]	= k
			ccorders[numccs] = v.order
		end
	end
	if self.db.char.bars.mergecc and not numccs == 0 then
		num = num + 1
	else
		num = num + numccs
		ccs = SquawkAndAwe:SortByValue(ccs, ccorders)		
	end
	
	-- Check for ability bars
	local abilities = {}
	local abilityorders = {}
	local numabilities = 0
	for k,v in pairs(self.db.char.bars.abilities) do
		if v.show then
			numabilities = numabilities + 1
			abilities[numabilities] = k
			abilityorders[numabilities] = v.order
		end
	end
	if self.db.char.bars.mergeabilities and not numabilities == 0 then
		num = num + 1
	else
		num = num + numabilities
		abilities = SquawkAndAwe:SortByValue(abilities, abilityorders)
	end

	-- Check for GCD bar
	if self.db.char.bars.GCD.show then
		num = num + 1
	end
	return num, procs, debuffs, ccs, abilities
end

-- Prints version number
function SquawkAndAwe:DisplayVersion()
	self:Print(self.version)
end

-- Clear the actives listings
function SquawkAndAwe:ClearActives()
    SquawkAndAwe.actives	= {}
	SquawkAndAwe.actives.trinkets	= {}
	SquawkAndAwe.actives.procs		= {}
	SquawkAndAwe.actives.cc			= {}
	SquawkAndAwe.actives.debuffs	= {}
	SquawkAndAwe.actives.abilities	= {}
end

function SquawkAndAwe:HideAllBars()
	for i,v in ipairs(SquawkAndAwe.barFrames) do
		v:Hide()
	end
end

-- Creates base frame, calls CreateBarFrames()
function SquawkAndAwe:SetBaseFrame()
	-- Basic config
	self.BaseFrame:SetScale(self.db.char.scale)
	self.BaseFrame:SetFrameStrata("BACKGROUND")
	local width
	self.BaseFrame:SetWidth(self.db.char.fWidth + (self.db.char.icons and self.db.char.barHeight + 9 or 0))
	local numbars, procs, debuffs, ccs, abilities = self:FindNumBars()
	self.BaseFrame:SetHeight((self.db.char.barHeight + 3) * numbars + 3)
	self.BaseFrame:SetBackdrop(self.frameBackdrop)
	self.BaseFrame:SetBackdropColor(1, 1, 1, 0)
	self.BaseFrame:SetMovable(true)
	self.BaseFrame:RegisterForDrag("LeftButton")
	self.BaseFrame:SetPoint(self.db.char.point, self.db.char.relativeTo, self.db.char.relativePoint, self.db.char.xOffset, self.db.char.yOffset)

	-- Set the start-drag script
	self.BaseFrame:SetScript("OnDragStart",
		function()
			self.BaseFrame:StartMoving();
		end );

	-- Set the stop-drag script
	self.BaseFrame:SetScript("OnDragStop",
		function()
			self.BaseFrame:StopMovingOrSizing();
			self.BaseFrame:SetScript("OnUpdate", nil);
			self:FinishedMoving(self.db.char, self.BaseFrame);
		end );

	-- Show the frame, reset the toggle
	self.BaseFrame:Show()
	self.db.char.barshow = false

	-- Create the bar frames
	self:CreateBarFrames(numbars, procs, debuffs, ccs, abilities)
end

-- Creates bar frames by iterating through categories and setting up each,
-- either merged or not
function SquawkAndAwe:CreateBarFrames(numbars, procs, debuffs, ccs, abilities)
	-- Bar creation
	local barCount
	local k,v
	local layer
	local add
	
	-- Do Growup stuff
	if self.db.char.bars.growup then
		barCount	= numbars - 1
	else
		barCount	= 0
	end
	
	-- Reset frames container
	self.frames = {}
	barFrameIndex = 0
	statusbarIndex = 0

	-- Trinket Bars
	if self.db.char.bars.trinketshow then
		if self.db.char.bars.mergetrinkets then
			SquawkAndAwe:SetBarFrame("Trinkets", barCount)
			SquawkAndAwe:AddStatusBar(self.frames["Trinkets"], "Trinket1", SquawkAndAwe.combat.trinkets.flare.color, 2)
			SquawkAndAwe:AddStatusBar(self.frames["Trinkets"], "Trinket2", SquawkAndAwe.combat.trinkets.flame.color, 1)
			if self.db.char.bars.growup then
				barCount = barCount - 1
			else
				barCount = barCount + 1
			end
		else
			-- First trinket bar
			if (self.db.char.bars.singletrinket) then
				SquawkAndAwe:SetBarFrame("Trinket1", barCount)
				if self.db.char.bars.growup then
					SquawkAndAwe:SetBarFrame("Trinket2", barCount - 1)
				else
					SquawkAndAwe:SetBarFrame("Trinket2", barCount + 1)
				end
				if self.db.char.bars.growup then
					barCount = barCount - 1
				else
					barCount = barCount + 1
				end
			else
				SquawkAndAwe:SetBarFrame("Trinket2", barCount)
				if self.db.char.bars.growup then
					SquawkAndAwe:SetBarFrame("Trinket1", barCount - 1)
				else
					SquawkAndAwe:SetBarFrame("Trinket1", barCount + 1)
				end
				if self.db.char.bars.growup then
					barCount = barCount - 2
				else
					barCount = barCount + 2
				end
			end
			if self.db.char.bars.trinketcd then
				SquawkAndAwe:AddStatusBar(self.frames["Trinket1"], "Trinket1CD", self.db.char.bars.cdcolor, 1)
				SquawkAndAwe:AddStatusBar(self.frames["Trinket1"], "Trinket1", SquawkAndAwe.combat.trinkets.flare.color, 2)
				SquawkAndAwe:AddStatusBar(self.frames["Trinket2"], "Trinket2CD", self.db.char.bars.cdcolor, 1)
				SquawkAndAwe:AddStatusBar(self.frames["Trinket2"], "Trinket2", SquawkAndAwe.combat.trinkets.flame.color, 2)
			else
				SquawkAndAwe:AddStatusBar(self.frames["Trinket1"], "Trinket1", SquawkAndAwe.combat.trinkets.flare.color, 1)
				SquawkAndAwe:AddStatusBar(self.frames["Trinket2"], "Trinket2", SquawkAndAwe.combat.trinkets.flame.color, 1)
			end
		end
	end

	-- Proc bars
	if self.db.char.bars.autoorder then
		for k,v in pairs(self.db.char.bars.procs) do
			if not ((k == "Eclipsew") or (k == "sounds"))then
				if v.show or v.cd then
					SquawkAndAwe:SetBarFrame(k, barCount, SquawkAndAwe.combat.procs[k].id)
					if v.cd then
						SquawkAndAwe:AddStatusBar(self.frames[k], k.."CD", self.db.char.bars.cdcolor, 1)
						if v.show then
							SquawkAndAwe:AddStatusBar(self.frames[k], k, v.color, 2)
						end
					else
						SquawkAndAwe:AddStatusBar(self.frames[k], k, v.color, 1)
					end
					if self.db.char.bars.growup then
						barCount = barCount - 1
					else
						barCount = barCount + 1
					end
				end
			end
		end
	else
		for i,v in ipairs(procs) do
			if self.db.char.bars.growup then
				SquawkAndAwe:SetBarFrame(v, barCount - #(procs) + i, SquawkAndAwe.combat.procs[v].id)
			else
				SquawkAndAwe:SetBarFrame(v, barCount + #(procs) - i, SquawkAndAwe.combat.procs[v].id)
			end
			if self.db.char.bars.procs[v].cd then
				SquawkAndAwe:AddStatusBar(self.frames[v], v.."CD", self.db.char.bars.cdcolor, 1)
				if self.db.char.bars.procs[v].show then
					SquawkAndAwe:AddStatusBar(self.frames[v], v, self.db.char.bars.procs[v].color, 2)
				end
			else
				SquawkAndAwe:AddStatusBar(self.frames[v], v, self.db.char.bars.procs[v].color, 1)
			end
		end
		if self.db.char.bars.growup then
			barCount = barCount - #(procs)
		else
			barCount = barCount + #(procs)
		end
	end
	
	-- Debuff bars
	layer = 1
	add = 0
	if self.db.char.bars.mergedebuffs then
		-- Make sure at least one is enabled
		for k,v in pairs(self.db.char.bars.debuffs)do
			if v.show then
				add = add + 1
			end
		end
		if add > 0 then
			SquawkAndAwe:SetBarFrame("Debuffs", barCount)
			for k,v in pairs(self.db.char.bars.debuffs) do
				if v.show then
					SquawkAndAwe:AddStatusBar(self.frames["Debuffs"], k, v.color, layer)
					layer = layer + 1
				end
			end
			if self.db.char.bars.growup then
				barCount = barCount - 1
			else
				barCount = barCount + 1
			end
		end
	elseif self.db.char.bars.autoorder then
		for k,v in pairs(self.db.char.bars.debuffs) do
			if v.show then
				SquawkAndAwe:SetBarFrame(k, barCount, SquawkAndAwe.combat.debuffs[k].id)
				SquawkAndAwe:AddStatusBar(self.frames[k], k, v.color, 1)
				if v.tick then
					SquawkAndAwe:AddStatusBar(self.frames[k], k.."Tick", self.db.char.bars.tickcolor, 2, true, SquawkAndAwe.combat.debuffs[k].tick)
				end
				if self.db.char.bars.growup then
					barCount = barCount - 1
				else
					barCount = barCount + 1
				end
			end
		end
	else
		for i,v in ipairs(debuffs) do
			if self.db.char.bars.growup then
				SquawkAndAwe:SetBarFrame(v, barCount - #(debuffs) + i, SquawkAndAwe.combat.debuffs[v].id)
			else
				SquawkAndAwe:SetBarFrame(v, barCount + #(debuffs) - i, SquawkAndAwe.combat.debuffs[v].id)
			end
			SquawkAndAwe:AddStatusBar(self.frames[v], v, self.db.char.bars.debuffs[v].color, 1)
			if self.db.char.bars.debuffs[v].tick then
				SquawkAndAwe:AddStatusBar(self.frames[v], v.."Tick", self.db.char.bars.tickcolor, 2, true, SquawkAndAwe.combat.debuffs[v].tick)
			end
		end
		if self.db.char.bars.growup then
			barCount = barCount - #(debuffs)
		else
			barCount = barCount + #(debuffs)
		end
	end

	-- CC bars
	layer = 1
	add = 0
	if self.db.char.bars.mergecc then
		-- Make sure at least one is enabled
		for k,v in pairs(self.db.char.bars.cc)do
			if v.show then
				add = add + 1
			end
		end
		if add > 0 then
			SquawkAndAwe:SetBarFrame("CC", barCount)
			for k,v in pairs(self.db.char.bars.cc) do
				if v.show then
					SquawkAndAwe:AddStatusBar(self.frames["CC"], k, v.color, layer)
					layer = layer + 1
				end
			end
			if self.db.char.bars.growup then
				barCount = barCount - 1
			else
				barCount = barCount + 1
			end
		end
	elseif self.db.char.bars.autoorder then
		for k,v in pairs(self.db.char.bars.cc) do
			if v.show then
				SquawkAndAwe:SetBarFrame(k, barCount, SquawkAndAwe.combat.cc[k].id)
				SquawkAndAwe:AddStatusBar(self.frames[k], k, v.color, 1)
				if self.db.char.bars.growup then
					barCount = barCount - 1
				else
					barCount = barCount + 1
				end
			end
		end
	else
		for i,v in ipairs(ccs) do
			if self.db.char.bars.growup then
				SquawkAndAwe:SetBarFrame(v, barCount - #(ccs) + i, SquawkAndAwe.combat.cc[v].id)
			else
				SquawkAndAwe:SetBarFrame(v, barCount + #(ccs) - i, SquawkAndAwe.combat.cc[v].id)
			end
			SquawkAndAwe:AddStatusBar(self.frames[v], v, self.db.char.bars.cc[v].color, 1)
		end
		if self.db.char.bars.growup then
			barCount = barCount - #(ccs)
		else
			barCount = barCount + #(ccs)
		end
	end


	-- Ability bars
	layer = 1
	add = 0
	if self.db.char.bars.mergeabilities then
		-- Make sure at least one is enabled
		for k,v in pairs(self.db.char.bars.abilities)do
			if v.show then
				add = add + 1
			end
		end
		if add > 0 then
		    SquawkAndAwe:SetBarFrame("Abilities", barCount)
			for k,v in pairs(self.db.char.bars.abilities) do
				if v.show then
					SquawkAndAwe:AddStatusBar(self.frames.Abilities, k, v.color, layer)
					layer = layer + 1
				end
			end
			if self.db.char.bars.growup then
				barCount = barCount - 1
			else
				barCount = barCount + 1
			end
		end
	elseif self.db.char.bars.autoorder then
		for k,v in pairs(self.db.char.bars.abilities) do
			if v.show then
				SquawkAndAwe:SetBarFrame(k, barCount, SquawkAndAwe.combat.abilities[k].id)
				if v.dur then
					SquawkAndAwe:AddStatusBar(self.frames[k], k.."Dur", v.color, 2)
					SquawkAndAwe:AddStatusBar(self.frames[k], k, self.db.char.bars.cdcolor, 1)
				else
					SquawkAndAwe:AddStatusBar(self.frames[k], k, v.color, 1)
				end
				if self.db.char.bars.growup then
					barCount = barCount - 1
				else
					barCount = barCount + 1
				end
			end
		end
	else
		for i,v in ipairs(abilities) do
			if self.db.char.bars.growup then
				SquawkAndAwe:SetBarFrame(v, barCount - #(abilities) + i, SquawkAndAwe.combat.abilities[v].id)
			else
				SquawkAndAwe:SetBarFrame(v, barCount + #(abilities) - i, SquawkAndAwe.combat.abilities[v].id)
			end
			if self.db.char.bars.abilities[v].dur then
				SquawkAndAwe:AddStatusBar(self.frames[v], v.."Dur", self.db.char.bars.abilities[v].color, 2)
				SquawkAndAwe:AddStatusBar(self.frames[v], v, self.db.char.bars.cdcolor, 1)
			else
				SquawkAndAwe:AddStatusBar(self.frames[v], v, self.db.char.bars.abilities[v].color, 1)
			end
		end
		if self.db.char.bars.growup then
			barCount = barCount - #(abilities)
		else
			barCount = barCount + #(abilities)
		end
	end

	-- GCD Bar
	if self.db.char.bars.GCD.show then
		SquawkAndAwe:SetBarFrame("GCD", barCount)
		SquawkAndAwe:AddStatusBar(self.frames["GCD"], "GCD", self.db.char.bars.GCD.color, 1)
	end
end

-- Can't destroy frames, so we have to reuse them
function SquawkAndAwe:GetNextBarFrame()
	barFrameIndex = barFrameIndex + 1

	-- Grab a frame from storage
	newFrame = SquawkAndAwe.barFrames[barFrameIndex]
	if newFrame then
		return newFrame
	end

	-- If it wasn't there, create a new one and put it in storage
	newFrame = CreateFrame("Frame", "SAABarFrame"..barFrameIndex, SquawkAndAwe.BaseFrame)
	SquawkAndAwe.barFrames[barFrameIndex] = newFrame
	return newFrame
end

-- Sets up the bar frame, given its offset in number of bars from the top
function SquawkAndAwe:SetBarFrame(frameName, frameOffset, spellID)
	local newFrame	= SquawkAndAwe:GetNextBarFrame()

	-- Set up the frame
	newFrame:SetFrameStrata("LOW")
	newFrame:SetWidth(self.db.char.fWidth)
	newFrame:SetHeight(self.db.char.barHeight)
	newFrame:ClearAllPoints()
	newFrame:SetPoint("TOPRIGHT", self.BaseFrame, "TOPRIGHT", 0, frameOffset * self.db.char.barHeight * -1 - 3)
	newFrame:SetBackdrop(self.barBackdrop);
	newFrame:SetBackdropColor(0, 0, 0, 0.2);
	newFrame:SetBackdropBorderColor( 1, 1, 1, 1);
	newFrame:EnableMouse(false)

	-- Set up the icon
	local _, icon
	-- Create frame
	if not newFrame.icon then
		newFrame.icon = CreateFrame("Frame", "SAA_"..frameName.."Icon", newFrame)
 	end

	-- Sizing and placement
	newFrame.icon:SetWidth(self.db.char.barHeight)
	newFrame.icon:SetHeight(self.db.char.barHeight)
	newFrame.icon:SetPoint("RIGHT", newFrame, "LEFT", -3, 0)

	-- If we were given a spell, apply the icon
	if spellID then
		_, _, icon = GetSpellInfo(spellID)
		newFrame.icon:SetBackdrop({bgFile = icon})
	end
	if self.db.char.icons then
	    newFrame.icon:Show()
 	else
    	newFrame.icon:Hide()
	end

	-- Set up the text
	-- Create the text overlay
	if not newFrame.text then
		newFrame.text = newFrame:CreateFontString(nil,"OVERLAY")
	end

	-- Apply font
	local barfont = media:Fetch("font", self.db.char.barfont)
	newFrame.text:SetFont(barfont, self.db.char.barfontsize)
	newFrame.text:SetTextColor(1, 1, 1, 1)

	-- Place text overlay
	newFrame.text:ClearAllPoints()
	if self.db.char.icons then
		newFrame.text:SetPoint("LEFT", newFrame.icon, "RIGHT", 9, 0)
	else
		newFrame.text:SetPoint("LEFT", newFrame, "LEFT", 6, 0)
	end

	-- Clear text
	newFrame.text:SetText("")

	-- Set update script
	newFrame:SetScript("OnUpdate",
		function()
			OnUpdate();
		end );

	-- Hide the frame
	newFrame:Hide()

	-- Add it to frame array
	self.frames[frameName] = newFrame
end

-- Can't destroy frames, so we have to reuse them
function SquawkAndAwe:GetNextStatusBar()
	statusbarIndex = statusbarIndex + 1

	-- Grab a frame from storage
	newFrame = SquawkAndAwe.statusBars[statusbarIndex]
	if newFrame then
		return newFrame
	end

	-- If it wasn't there, create a new one and put it in storage
	newFrame = CreateFrame("StatusBar", "SAA_Statusbar"..statusbarIndex, SquawkAndAwe.BaseFrame)
	SquawkAndAwe.statusBars[statusbarIndex] = newFrame
	return newFrame
end

-- Adds a status bar to a bar frame. If isTick is set, the bar is 1/3 height,
-- and max/min values are changed
function SquawkAndAwe:AddStatusBar(addToFrame, newFrameName, colors, frameLevel, isTick, tickDur)
	statusbar = SquawkAndAwe:GetNextStatusBar()
	statusbar:SetParent(addToFrame)

	statusbar:SetFrameLevel(frameLevel)
	statusbar:ClearAllPoints()
	statusbar:SetHeight((self.db.char.barHeight - 6) / (isTick and 3 or 1))
	statusbar:SetWidth(self.db.char.fWidth - 6)
	statusbar:SetPoint("BOTTOMRIGHT", addToFrame, "BOTTOMRIGHT", -3, 3)
	statusbar:SetStatusBarTexture(media:Fetch("statusbar", self.db.char.texture))
	statusbar:GetStatusBarTexture():SetHorizTile(false)
	statusbar:SetStatusBarColor(colors.r, colors.g, colors.b, colors.a)
	if isTick then
		statusbar:SetMinMaxValues(0,tickDur)
		statusbar:SetValue(tickDur / 2)
	-- Special case for GCD bar
	elseif newFrameName == "GCD" then
	    statusbar:SetMinMaxValues(0,1.5)
	    statusbar:SetValue(.75)
	else
		statusbar:SetMinMaxValues(0, self.db.char.bars.MaxLen)
		statusbar:SetValue(15)
	end

	-- Add the spark
	if not statusbar.spark then
		statusbar.spark = statusbar:CreateTexture(nil, "OVERLAY")
	end
	statusbar.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
	statusbar.spark:SetWidth(16)
	statusbar.spark:SetHeight(self.db.char.barHeight + 10)
	statusbar.spark:SetBlendMode("ADD")
	statusbar.spark:SetPoint("CENTER", statusbar, "LEFT",(self.db.char.fWidth - 6)* 15/self.db.char.bars.MaxLen, -1)

	-- Hide it for ticks
	if istick then
		statusbar.spark:Show()
	else
		statusbar.spark:Hide()
	end

	addToFrame[newFrameName] = statusbar
end

-- Resets bars to center of screen
function SquawkAndAwe:ResetBars()
	self.BaseFrame:ClearAllPoints()
	self.db.char.point			= SquawkAndAwe.defaults.char.point
	self.db.char.relativeTo		= SquawkAndAwe.defaults.char.relativeTo
	self.db.char.relativePoint	= SquawkAndAwe.defaults.char.relativePoint
	self.db.char.xOffset		= SquawkAndAwe.defaults.char.xOffset
	self.db.char.yOffset		= SquawkAndAwe.defaults.char.yOffset
	self.db.char.fWidth			= SquawkAndAwe.defaults.char.fWidth
	self.db.char.barHeight		= SquawkAndAwe.defaults.char.barHeight
	self.db.char.scale			= SquawkAndAwe.defaults.char.scale
	self.db.char.barfont		= SquawkAndAwe.defaults.char.barfont
	self.db.char.barfontsize	= SquawkAndAwe.defaults.char.barfontsize
	self.db.char.bartexture		= SquawkAndAwe.defaults.char.bartexture
	self.db.char.texture		= SquawkAndAwe.defaults.char.texture
	barshow = true
	self.BaseFrame:SetPoint(self.db.char.point, self.db.char.relativeTo, self.db.char.relativePoint, self.db.char.xOffset, self.db.char.yOffset)
	self:RedrawFrames()
	self.db.char.barshow = true -- so that call to ShowHideBars resets to false
	self:ShowHideBars()
end

-- Handles activating Trinket bars
function SquawkAndAwe:TrinketBars(k, v)
    -- Trinket 1 already active, move to 2
	if SquawkAndAwe.actives.trinkets.Trinket1 then
		SquawkAndAwe.actives.trinkets.Trinket2 = true
		SquawkAndAwe.activeTrinketNames.Trinket2 = k
		if v.cd and self.db.char.bars.trinketcd then
			SquawkAndAwe.times.Trinket2CD = GetTime() + v.cd
		end
		if self.db.char.bars.mergetrinkets then
			self.frames.Trinkets.Trinket2:SetStatusBarColor(v.color.r, v.color.g, v.color.b, v.color.a)
			self.frames.Trinkets.Trinket2:Show()
			-- Must set icon in OnUpdate(). Lowest duration trinket effect is not immutable
		else
		    self.frames.Trinket2.Trinket2:SetStatusBarColor(v.color.r, v.color.g, v.color.b, v.color.a)
			if self.db.char.icons then
				_,_,icon = GetSpellInfo(v.id)
				self.frames.Trinket2.icon:SetBackdrop({bgFile = icon})
			end
			self.frames.Trinket2:Show()
		end
	else
		SquawkAndAwe.actives.trinkets.Trinket1 = true
		SquawkAndAwe.activeTrinketNames.Trinket1 = k
		if v.cd and self.db.char.bars.trinketcd then
			SquawkAndAwe.times.Trinket1CD = GetTime() + v.cd
		end
		if self.db.char.bars.mergetrinkets then
			self.frames.Trinkets.Trinket1:SetStatusBarColor(v.color.r, v.color.g, v.color.b, v.color.a)
			self.frames.Trinkets:Show()
			self.frames.Trinkets.Trinket2:Hide()
		else
		    if self.db.char.bars.trinketcd then
		        SquawkAndAwe.actives.Trinket1CD = true
		    end
			self.frames.Trinket1.Trinket1:SetStatusBarColor(v.color.r, v.color.g, v.color.b, v.color.a)
			if self.db.char.icons then
				_,_,icon = GetSpellInfo(v.id)
				self.frames.Trinket1.icon:SetBackdrop({bgFile = icon})
			end
			self.frames.Trinket1:Show()
		end -- if mergetrinkets
	end -- if actives.Trinket1
end

-- Handles activating Proc bars
function SquawkAndAwe:ProcBars(k, v) -- SquawkAndAwe.combat.procs[k] = v
	local color, barname
    -- Special handling for Wrath Eclipse
	if k == "Eclipsew" then barname = "Eclipse" else barname = k end
	if self.db.char.bars.procs[barname].show or self.db.char.bars.procs[barname].cd then
		--[[if v.id == SquawkAndAwe.combat.procs.Eclipse.id then
			EclipseType = SquawkAndAwe.combat.Starfire.name
		end]]--
		-- Handling for purged Eclipse/Eclipse overwrite
		if barname == "Eclipse" then 
			SquawkAndAwe.ActiveEclipseBuff	= true 
			if k == "Eclipse" then 
				SquawkAndAwe.actives.procs.Eclipsew	= false
			else
				SquawkAndAwe.actives.procs.Eclipse	= false
			end
		end
		if self.db.char.bars.procs[barname].show then
			color = self.db.char.bars.procs[k].color
			self.frames[barname][barname]:SetStatusBarColor(color.r, color.g, color.b, color.a)
			SquawkAndAwe.actives.procs[k] = true
		end
		if self.db.char.bars.procs.sounds then
			local soundfile	= media:Fetch("sound", self.db.char.bars.procs[k].sound)
			if soundfile then
				PlaySoundFile(soundfile)
			end
		end
		if v.cd then
			SquawkAndAwe.times[k.."CD"] = GetTime() + v.cd
		end
		if self.db.char.bars.procs[k].cd then
			SquawkAndAwe.actives[k.."CD"] = true
		end
		if self.db.char.icons then
			_,_,icon = GetSpellInfo(v.id)
			self.frames[barname].icon:SetBackdrop({bgFile = icon})
		end
		self.frames[barname]:Show()
	end -- if spellID == Wrath else if show
end

-- Handles activating Debuff bars
function SquawkAndAwe:DebuffBars(k, v, notick)
	if self.db.char.bars.debuffs[k].show then
	    SquawkAndAwe.actives.debuffs[k] = true
		if self.db.char.bars.mergedebuffs then
			self.frames.Debuffs:Show()
		else
			if self.db.char.bars.debuffs[k].tick and not notick then
				SquawkAndAwe.times[k.."Tick"] = GetTime() + v.tick
				SquawkAndAwe.actives[k.."Tick"] = true
			end
			self.frames[k]:Show()
		end
	end -- if v.show
end

function SquawkAndAwe:TriggerDebuffs()
	for k,v in pairs(SquawkAndAwe.combat.debuffs) do
		if SquawkAndAwe.db.char.bars.debuffs[k].show then
			SquawkAndAwe:DebuffBars(k, v, true)
		end
	end
end

-- Handles activting CC bars
function SquawkAndAwe:CCBars(k)
    if self.db.char.bars.cc[k].show then
		SquawkAndAwe.actives.cc[k] = true
		if self.db.char.bars.mergecc then
			self.frames.CC:Show()
		else
			self.frames[k]:Show()
		end
	end
end

function SquawkAndAwe:TriggerCC()
	for k,v in pairs(SquawkAndAwe.combat.cc) do
		if SquawkAndAwe.db.char.bars.cc[k].show then
	    	SquawkAndAwe:CCBars(k)
		end
	end
end

-- Handles activating Ability bars
function SquawkAndAwe:AbilityBars(k, v)
	if self.db.char.bars.abilities[k].show then
		SquawkAndAwe.actives.abilities[k] = true
		if self.db.char.bars.mergeabilities then
			self.frames.Abilities:Show()
		else
			if self.db.char.bars.abilities[k].dur then
				if v.dur then
					SquawkAndAwe.times[k.."Dur"] = GetTime() + v.dur
				end
			end
			self.frames[k]:Show()
		end
	end
end

-- Handles activating the GCD bar
function SquawkAndAwe:GCDBar()
	local startTime, duration, enabled = GetSpellCooldown(SquawkAndAwe.combat.Moonglade.name) -- TM chosen because it has no other cooldown and all druids will have it
	if duration > 0 then
		self.frames["GCD"]:Show()
		SquawkAndAwe.actives.GCD = true
	end
end

function SquawkAndAwe:DurationString(duration)
    local string = (("%1.1f"):format(duration % 60)) .. "s";

    if (duration >= 60) then
        duration = floor(duration - (duration % 60)) / 60; -- minutes

        string = (duration % 60) .."m " .. string;

        if (duration >= 60) then
            duration = (duration - (duration % 60)) / 60; -- hours
            string = duration .. "h " .. string;
        end
    end
    return string
end

-- Sorts two arrays by the values in one array. Nominally, sorts keys by
-- duration, descending. i.e. after sort, keys[0] will be the last to drop
function SquawkAndAwe:SortByValue(keys, vals)
	local i,v
	local swap = true

 	while swap do
	    swap = false
	    for i,v in ipairs(vals) do
            if vals[i + 1] and v < vals[i + 1] then
	        	vals[i + 1], vals[i] = vals[i], vals[i + 1]
				keys[i + 1], keys[i] = keys[i], keys[i + 1]
				swap = true
			end
	    end
	end

	return keys, vals
end

function OnUpdate()
	local width = SquawkAndAwe.db.char.fWidth - 6
	local sparkscale = width / SquawkAndAwe.db.char.bars.MaxLen
	local timeLeft = 0
	local namestring = ""
	local durstring = ""
	local k,v,i,_,icon
	local sort = {}
	local durs = {}

	-- Handle Trinket updates
	if SquawkAndAwe.db.char.bars.trinketshow then
		if SquawkAndAwe.db.char.bars.mergetrinkets then
			namestring = ""
			durstring = ""
			i = 1
			if SquawkAndAwe.actives.trinkets.Trinket1 then
				sort[i] = "Trinket1"
				if SquawkAndAwe.db.char.bars.trinketcd then
				    if SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames.Trinket1].cd then
				        durs[i] = SquawkAndAwe.times.Trinket1CD - GetTime()
				    else
						durs[i] = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames.Trinket1].itemname, "item") - GetTime()
					end
				else
					durs[i] = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames.Trinket1].name, "buff") - GetTime()
				end
				if durs[i] < 0 then
					SquawkAndAwe.actives.trinkets.Trinket1 = false
					SquawkAndAwe.frames.Trinkets.Trinket1:Hide()
    				SquawkAndAwe.frames.Trinkets.Trinket1.spark:Hide()
				else
					i = i + 1
					SquawkAndAwe.frames.Trinkets.Trinket1:Show()
					SquawkAndAwe.frames.Trinkets.Trinket1.spark:Show()
				end
			end
			if SquawkAndAwe.actives.trinkets.Trinket2 then
				sort[i] = "Trinket2"
				if SquawkAndAwe.db.char.bars.trinketcd then
				    if SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames.Trinket2].cd then
				        durs[i] = SquawkAndAwe.times.Trinket2CD - GetTime()
				    else
						durs[i] = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames.Trinket2].itemname, "item") - GetTime()
					end
				else
					durs[i] = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames.Trinket2].name, "buff") - GetTime()
				end
				if durs[i] < 0 then
					SquawkAndAwe.actives.trinkets.Trinket2 = false
					SquawkAndAwe.frames.Trinkets.Trinket2:Hide()
    				SquawkAndAwe.frames.Trinkets.Trinket2.spark:Hide()
				else
					i = i + 1
					SquawkAndAwe.frames.Trinkets.Trinket2:Show()
					SquawkAndAwe.frames.Trinkets.Trinket2.spark:Show()
				end
			end
			if i > 1 then
				sort, durs = SquawkAndAwe:SortByValue(sort, durs)
				if SquawkAndAwe.db.char.icons then
					_,_,icon = GetSpellInfo(SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[sort[i-1]]].id)
					SquawkAndAwe.frames.Trinkets.icon:SetBackdrop({bgFile = icon})
					SquawkAndAwe.frames.Trinkets.icon:Show()
				end
				if SquawkAndAwe.db.char.spellnames then
					local trinket	= SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[sort[i-1]]]
					local trinketname	= trinket.shortname or trinket.itemname
					namestring = trinketname..(SquawkAndAwe.db.char.bars.trinketcd and " "..L["Cooldown"] or "")..(SquawkAndAwe.db.char.durations and ": " or "")
				end
				if SquawkAndAwe.db.char.durations then
					durstring = SquawkAndAwe:DurationString(durs[i-1])
				end
				if SquawkAndAwe.db.char.barstext then
					SquawkAndAwe.frames.Trinkets.text:SetText(namestring..durstring)
				end
				while i > 1 do
					i = i - 1
					k = sort[i]
					SquawkAndAwe.frames.Trinkets[k]:SetFrameLevel(i)
					timeLeft = math.min(durs[i], SquawkAndAwe.db.char.bars.MaxLen)
					SquawkAndAwe.frames.Trinkets[k]:SetValue(timeLeft)
					SquawkAndAwe.frames.Trinkets[k].spark:SetPoint("CENTER", SquawkAndAwe.frames.Trinkets[k], "LEFT", timeLeft * sparkscale, 0)
					SquawkAndAwe.frames.Trinkets[k].spark:Show()
				end
 			elseif not SquawkAndAwe.db.char.barshow then
				SquawkAndAwe.frames.Trinkets:Hide()
			end
		else
			for k,v in pairs(SquawkAndAwe.actives.trinkets) do
				namestring = ""
				durstring = ""
				if v then
					if SquawkAndAwe.db.char.bars.trinketcd and not (SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[k]].cd == 0) then
						if SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[k]].cd then
							timeLeft = SquawkAndAwe.times[k.."CD"] - GetTime()
						else
						    timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[k]].itemname, "item") - GetTime()
						end
						if timeLeft < 0 then
						    SquawkAndAwe.actives.trinkets[k] = false
						    SquawkAndAwe.frames[k]:Hide()
						    SquawkAndAwe.frames[k].text:SetText("")
						else
						    if SquawkAndAwe.db.char.spellnames then
							    local trinket	= SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[k]]
								local trinketname	= trinket.shortname or trinket.itemname
								namestring = trinketname.." "..L["Cooldown"]..(SquawkAndAwe.db.char.durations and ": " or "")
							end
							if SquawkAndAwe.db.char.durations then durstring = SquawkAndAwe:DurationString(timeLeft) end
							timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
							SquawkAndAwe.frames[k][k.."CD"]:SetValue(timeLeft)
							SquawkAndAwe.frames[k][k.."CD"].spark:SetPoint("CENTER", SquawkAndAwe.frames[k][k.."CD"], "LEFT", timeLeft * sparkscale, 0)
							SquawkAndAwe.frames[k][k.."CD"].spark:Show()
							SquawkAndAwe.frames[k].text:SetText(namestring..durstring)
						end
					end
					timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[k]].name, "buff") - GetTime()
					if timeLeft > 0 then
					    if SquawkAndAwe.db.char.spellnames then
						    local trinket = SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[k]]
							local trinketname = trinket.shortname or trinket.itemname
							namestring = trinketname..(SquawkAndAwe.db.char.durations and ": " or "")
						end
						if SquawkAndAwe.db.char.durations then durstring = SquawkAndAwe:DurationString(timeLeft) end
						timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
						SquawkAndAwe.frames[k][k]:SetValue(timeLeft)
						SquawkAndAwe.frames[k][k].spark:SetPoint("CENTER", SquawkAndAwe.frames[k][k], "LEFT", timeLeft * sparkscale, 0)
						SquawkAndAwe.frames[k][k].spark:Show()
						SquawkAndAwe.frames[k][k]:Show()
						SquawkAndAwe.frames[k].text:SetText(namestring..durstring)
					else
						SquawkAndAwe.frames[k][k]:Hide()
						if (not SquawkAndAwe.db.char.bars.trinketcd) or (SquawkAndAwe.combat.trinkets[SquawkAndAwe.activeTrinketNames[k]].cd == 0) then
					    	SquawkAndAwe.actives.trinkets[k] = false
							SquawkAndAwe.frames[k]:Hide()
							SquawkAndAwe.frames[k].text:SetText("")
						end
					end
				end
			end -- for k,v in trinkets
		end -- if mergetrinkets
	end -- if trinketshow

	-- Handle Proc updates
	local barname
	for k,v in pairs(SquawkAndAwe.actives.procs) do
		namestring = ""
		durstring = ""
		if k == "Eclipsew" then	barname	= "Eclipse"	else barname = k end	
		if v and SquawkAndAwe.db.char.bars.procs[barname].show then
   			if SquawkAndAwe.db.char.bars.procs[barname].cd then
				timeLeft = SquawkAndAwe.times[k.."CD"] - GetTime()
				if timeLeft < 0 then
				    SquawkAndAwe.actives.procs[k] = false
					if not ((k == "Eclipsew" and SquawkAndAwe.actives.procs.Eclipse) or (k == "Eclipse" and SquawkAndAwe.actives.procs.Eclipsew)) then
						SquawkAndAwe.frames[barname]:Hide()
						SquawkAndAwe.frames[barname].text:SetText("")
					end
				else
					if SquawkAndAwe.db.char.spellnames then
					    namestring = SquawkAndAwe.combat.procs[k].name.." "..L["Cooldown"]..(SquawkAndAwe.db.char.durations and ": " or "")
					end
					if SquawkAndAwe.db.char.durations then durstring = SquawkAndAwe:DurationString(timeLeft) end
					timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
					SquawkAndAwe.frames[barname][barname.."CD"]:SetValue(timeLeft)
					SquawkAndAwe.frames[barname][barname.."CD"].spark:SetPoint("CENTER", SquawkAndAwe.frames[barname][barname.."CD"], "LEFT", timeLeft * sparkscale, 0)
					SquawkAndAwe.frames[barname][barname.."CD"].spark:Show()
					SquawkAndAwe.frames[barname].text:SetText(namestring..durstring)
				end
			end
			if SquawkAndAwe.db.char.bars.procs[barname].show then
				timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.procs[k].name, "buff") - GetTime()
				if timeLeft > 0 then
			    	if SquawkAndAwe.db.char.spellnames then
					    namestring = SquawkAndAwe.combat.procs[k].name..(SquawkAndAwe.db.char.durations and ": " or "")
					end
					if SquawkAndAwe.db.char.durations then durstring = SquawkAndAwe:DurationString(timeLeft) end
					timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
					SquawkAndAwe.frames[barname][barname]:SetValue(timeLeft)
					SquawkAndAwe.frames[barname][barname].spark:SetPoint("CENTER", SquawkAndAwe.frames[barname][barname], "LEFT", timeLeft * sparkscale, 0)
					SquawkAndAwe.frames[barname][barname].spark:Show()
					SquawkAndAwe.frames[barname][barname]:Show()
					if SquawkAndAwe.db.char.bars.procs[barname].flash then
      					UIFrameFlash(SquawkAndAwe.frames[barname][barname], 0.25, 0.25, 30, true, 0.25, 0.25)
					end
					SquawkAndAwe.frames[barname].text:SetText(namestring..durstring)
				else
					-- Special handling for Eclipse, as losing the buff means the opposite CD is still in effect.
					if barname == "Eclipse" then
						if SquawkAndAwe.ActiveEclipseBuff then
							SquawkAndAwe.ActiveEclipseBuff = false
							UIFrameFlashRemoveFrame(SquawkAndAwe.frames.Eclipse.Eclipse)
							SquawkAndAwe.frames.Eclipse.Eclipse:SetStatusBarColor(0.3, 0.3, 0.3, 0.9)
						end
						timeLeft = SquawkAndAwe.times[k.."CD"] - GetTime() - 15
						if timeLeft < 0 then
						    SquawkAndAwe.frames.Eclipse.Eclipse:Hide()
						else
							if SquawkAndAwe.db.char.spellnames then
								local opposite
								if k == "Eclipse" then opposite = SquawkAndAwe.combat.procs.Eclipsew.name else opposite = SquawkAndAwe.combat.procs.Eclipse.name end
								namestring = opposite..L["Cooldown"]..(SquawkAndAwe.db.char.durations and ": " or "")
							end
							if SquawkAndAwe.db.char.durations then durstring = SquawkAndAwe:DurationString(timeLeft) end
							timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
							SquawkAndAwe.frames.Eclipse.Eclipse:SetValue(timeLeft)
							SquawkAndAwe.frames.Eclipse.Eclipse.spark:SetPoint("CENTER", SquawkAndAwe.frames.Eclipse.Eclipse, "LEFT", timeLeft * sparkscale, 0)
							SquawkAndAwe.frames.Eclipse.Eclipse.spark:Show()
							SquawkAndAwe.frames.Eclipse.text:SetText(namestring..durstring)
						end
					else
						SquawkAndAwe.frames[k][k]:Hide()
						UIFrameFlashRemoveFrame(SquawkAndAwe.frames[k][k])
						if not SquawkAndAwe.db.char.bars.procs[k].cd then
			    			SquawkAndAwe.actives.procs[k] = false
							SquawkAndAwe.frames[k]:Hide()
							SquawkAndAwe.frames[k].text:SetText("")
						end
					end
				end
			end
		end
	end

	-- Handle Debuff updates
	if SquawkAndAwe.db.char.bars.mergedebuffs then
		namestring = ""
		durstring = ""
		i = 1
		-- Find out how many are active
		for k,v in pairs(SquawkAndAwe.db.char.bars.debuffs) do
			if v.show and SquawkAndAwe.actives.debuffs[k] then
				sort[i] = k
				durs[i] = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.debuffs[k].name, "debuff") - GetTime()
				if durs[i] < 0 then
					SquawkAndAwe.actives.debuffs[k] = false
					SquawkAndAwe.frames.Debuffs[k]:Hide()
     				SquawkAndAwe.frames.Debuffs[k].spark:Hide()
				else
					i = i + 1
					SquawkAndAwe.frames.Debuffs[k]:Show()
					SquawkAndAwe.frames.Debuffs[k].spark:Show()
				end
			elseif v.show and not SquawkAndAwe.db.char.barshow then
				SquawkAndAwe.frames.Debuffs[k]:Hide()
    			SquawkAndAwe.frames.Debuffs[k].spark:Hide()
			end
		end
		if i > 1 then
			sort, durs = SquawkAndAwe:SortByValue(sort, durs)
			if	SquawkAndAwe.db.char.icons then
				_,_,icon = GetSpellInfo(SquawkAndAwe.combat.debuffs[sort[i-1]].id)
				SquawkAndAwe.frames.Debuffs.icon:SetBackdrop({bgFile = icon})
				SquawkAndAwe.frames.Debuffs.icon:Show()
			end
			if SquawkAndAwe.db.char.spellnames then
				namestring = SquawkAndAwe.combat.debuffs[sort[i-1]].name..(SquawkAndAwe.db.char.durations and ": " or "")
			end
			if SquawkAndAwe.db.char.durations then
				durstring = SquawkAndAwe:DurationString(durs[i-1])
			end
			if SquawkAndAwe.db.char.barstext then
				SquawkAndAwe.frames.Debuffs.text:SetText(namestring..durstring)
			end
			while i > 1 do
				i = i - 1
				k = sort[i]
				SquawkAndAwe.frames.Debuffs[k]:SetFrameLevel(i)
				timeLeft = math.min(durs[i], SquawkAndAwe.db.char.bars.MaxLen)
				SquawkAndAwe.frames.Debuffs[k]:SetValue(timeLeft)
				SquawkAndAwe.frames.Debuffs[k].spark:SetPoint("CENTER", SquawkAndAwe.frames.Debuffs[k], "LEFT", timeLeft * sparkscale, 0)
				SquawkAndAwe.frames.Debuffs[k].spark:Show()
			end
		elseif ((not SquawkAndAwe.db.char.barshow) and SquawkAndAwe.frames.Debuffs) then
			SquawkAndAwe.frames.Debuffs:Hide()
		end
	else
		for k,v in pairs(SquawkAndAwe.actives.debuffs) do
			namestring = ""
			durstring = ""
			if v then
				timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.debuffs[k].name, "debuff") - GetTime()
				if (timeLeft < 0) then
					SquawkAndAwe.actives.debuffs[k] = false
					SquawkAndAwe.frames[k]:Hide()
					SquawkAndAwe.frames[k].text:SetText("")
				else
					if SquawkAndAwe.db.char.spellnames then
						namestring = SquawkAndAwe.combat.debuffs[k].name
						if k == "Moonfire" and SquawkAndAwe.db.char.sfcomboshow then
						    -- We set LastMF to 0 when we activate the bar.
							if ((not (LastMF == 0)) and timeLeft > LastMF) then
								SFCombos = SFCombos + 1
							end
						    LastMF = timeLeft
						    namestring = namestring.." ("..SFCombos..")"
						end
						if SquawkAndAwe.db.char.durations then namestring = namestring..": " end
					end
					if SquawkAndAwe.db.char.durations then	durstring = SquawkAndAwe:DurationString(timeLeft) end
					if SquawkAndAwe.db.char.barstext then SquawkAndAwe.frames[k].text:SetText(namestring..durstring)end
					timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
					SquawkAndAwe.frames[k][k]:SetValue(timeLeft)
					SquawkAndAwe.frames[k][k].spark:SetPoint("CENTER", SquawkAndAwe.frames[k][k], "LEFT", timeLeft * sparkscale, 0)
					SquawkAndAwe.frames[k][k].spark:Show()
					if SquawkAndAwe.db.char.bars.debuffs[k].tick then
						timeLeft = SquawkAndAwe.times[k.."Tick"] - GetTime()
						if timeLeft < 0 then
							SquawkAndAwe.frames[k][k.."Tick"]:Hide()
						else
							timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
							SquawkAndAwe.frames[k][k.."Tick"]:Show()
							SquawkAndAwe.frames[k][k.."Tick"]:SetValue(timeLeft)
							SquawkAndAwe.frames[k][k.."Tick"].spark:SetPoint("CENTER", SquawkAndAwe.frames[k][k.."Tick"], "LEFT", timeLeft * SquawkAndAwe.db.char.fWidth / 1.5 + 1, -1)
						end
					end
				end
			end
		end
	end

	-- Handle CC updates
	if SquawkAndAwe.db.char.bars.mergecc then
		namestring = ""
		durstring = ""
		i = 1
		-- Find out how many are active
		for k,v in pairs(SquawkAndAwe.db.char.bars.cc) do
			if v.show and SquawkAndAwe.actives.cc[k] then
				sort[i] = k
				durs[i] = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.cc[k].name, "cc") - GetTime()
				if durs[i] < 0 then
					SquawkAndAwe.actives.cc[k] = false
					SquawkAndAwe.frames.CC[k]:Hide()
					SquawkAndAwe.frames.CC[k].spark:Hide()
				else
					i = i + 1
					SquawkAndAwe.frames.CC[k]:Show()
					SquawkAndAwe.frames.CC[k].spark:Show()
				end
			elseif v.show and not SquawkAndAwe.db.char.barshow then
				SquawkAndAwe.frames.CC[k]:Hide()
				SquawkAndAwe.frames.CC[k].spark:Hide()
			end
		end
		if i > 1 then
			sort, durs = SquawkAndAwe:SortByValue(sort, durs)
			if SquawkAndAwe.db.char.icons then
				_,_,icon = GetSpellInfo(SquawkAndAwe.combat.cc[sort[i-1] ].id)
				SquawkAndAwe.frames.CC.icon:SetBackdrop({bgFile = icon})
				SquawkAndAwe.frames.CC.icon:Show()
			end
			if SquawkAndAwe.db.char.spellnames then
				namestring = SquawkAndAwe.combat.cc[sort[i-1] ].name..(SquawkAndAwe.db.char.durations and ": " or "")
			end
			if SquawkAndAwe.db.char.durations then
				durstring = SquawkAndAwe:DurationString(durs[i-1])
			end
			if SquawkAndAwe.db.char.barstext then
				SquawkAndAwe.frames.CC.text:SetText(namestring..durstring)
			end
			while i > 1 do
				i = i - 1
				k = sort[i]
				SquawkAndAwe.frames.CC[k]:SetFrameLevel(i)
				timeLeft = math.min(durs[i], SquawkAndAwe.db.char.bars.MaxLen)
				SquawkAndAwe.frames.CC[k]:SetValue(timeLeft)
				SquawkAndAwe.frames.CC[k].spark:SetPoint("CENTER", SquawkAndAwe.frames.CC[k], "LEFT", timeLeft * sparkscale, 0)
				SquawkAndAwe.frames.CC[k].spark:Show()
			end
		elseif ((not SquawkAndAwe.db.char.barshow) and SquawkAndAwe.frames.CC) then
		    SquawkAndAwe.frames.CC:Hide()
		end
	else
		for k,v in pairs(SquawkAndAwe.actives.cc) do
			namestring = ""
			durstring = ""
			if v then
				timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.cc[k].name, "cc") - GetTime()
				if (timeLeft < 0) then
					SquawkAndAwe.actives.cc[k] = false
					SquawkAndAwe.frames[k]:Hide()
					SquawkAndAwe.frames[k].text:SetText("")
				else
					if SquawkAndAwe.db.char.spellnames then
						namestring = SquawkAndAwe.combat.cc[k].name
						if SquawkAndAwe.db.char.durations then namestring = namestring..": " end
					end
					if SquawkAndAwe.db.char.durations then	durstring = SquawkAndAwe:DurationString(timeLeft) end
					if SquawkAndAwe.db.char.barstext then SquawkAndAwe.frames[k].text:SetText(namestring..durstring)end
					timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
					SquawkAndAwe.frames[k][k]:SetValue(timeLeft)
					SquawkAndAwe.frames[k][k].spark:SetPoint("CENTER", SquawkAndAwe.frames[k][k], "LEFT", timeLeft * sparkscale, 0)
					SquawkAndAwe.frames[k][k].spark:Show()
				end
			end
		end
	end

	-- Handle Ability updates
	if SquawkAndAwe.db.char.bars.mergeabilities then
		namestring = ""
		durstring = ""
		i = 1
		-- Find out how many are active
		for k,v in pairs(SquawkAndAwe.db.char.bars.abilities) do
			if v.show and SquawkAndAwe.actives.abilities[k] then
				sort[i] = k
				durs[i] = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.abilities[k].name, "cd") - GetTime()
				if durs[i] < 0 then
					if SquawkAndAwe.db.char.bars.procs.sounds then
						local soundfile	= media:Fetch("sound", SquawkAndAwe.db.char.bars.abilities[k].sound)
						if soundfile then
							PlaySoundFile(soundfile)
						end
					end
					SquawkAndAwe.actives.abilities[k] = false
					SquawkAndAwe.frames.Abilities[k]:Hide()
					SquawkAndAwe.frames.Abilities[k].spark:Hide()
				else
					i = i + 1
					SquawkAndAwe.frames.Abilities[k]:Show()
					SquawkAndAwe.frames.Abilities[k].spark:Show()
				end
			elseif v.show and not SquawkAndAwe.db.char.barshow then
				SquawkAndAwe.frames.Abilities[k]:Hide()
				SquawkAndAwe.frames.Abilities[k].spark:Hide()
			end
		end
		if i > 1 then
			sort, durs = SquawkAndAwe:SortByValue(sort, durs)
			if SquawkAndAwe.db.char.icons then
				_,_,icon = GetSpellInfo(SquawkAndAwe.combat.abilities[sort[i-1]].id)
				SquawkAndAwe.frames.Abilities.icon:SetBackdrop({bgFile = icon})
				SquawkAndAwe.frames.Abilities.icon:Show()
			end
			if SquawkAndAwe.db.char.spellnames then
				namestring = SquawkAndAwe.combat.abilities[sort[i-1]].name..(SquawkAndAwe.db.char.durations and ": " or "")
			end
			if SquawkAndAwe.db.char.durations then
				durstring = SquawkAndAwe:DurationString(durs[i-1])
			end
			if SquawkAndAwe.db.char.barstext then
				SquawkAndAwe.frames.Abilities.text:SetText(namestring..durstring)
			end
			while i > 1 do
				i = i - 1
				k = sort[i]
				SquawkAndAwe.frames.Abilities[k]:SetFrameLevel(i)
				timeLeft = math.min(durs[i], SquawkAndAwe.db.char.bars.MaxLen)
				SquawkAndAwe.frames.Abilities[k]:SetValue(timeLeft)
				SquawkAndAwe.frames.Abilities[k].spark:SetPoint("CENTER", SquawkAndAwe.frames.Abilities[k], "LEFT", timeLeft * sparkscale, 0)
				SquawkAndAwe.frames.Abilities[k].spark:Show()
			end
		elseif ((not SquawkAndAwe.db.char.barshow) and SquawkAndAwe.frames.Abilities) then
			SquawkAndAwe.frames.Abilities:Hide()
		end
	else
		for k,v in pairs(SquawkAndAwe.actives.abilities) do
			namestring = ""
			durstring = ""
			if v then
				timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.abilities[k].name, "cd") - GetTime()
				if (timeLeft < 0) then
					if SquawkAndAwe.db.char.bars.procs.sounds then
						local soundfile	= media:Fetch("sound", SquawkAndAwe.db.char.bars.abilities[k].sound)
						if soundfile then
							PlaySoundFile(soundfile)
						end
					end
					SquawkAndAwe.actives.abilities[k] = false
					SquawkAndAwe.frames[k]:Hide()
					SquawkAndAwe.frames[k].text:SetText("")
				else
					if SquawkAndAwe.db.char.spellnames then
						namestring = SquawkAndAwe.combat.abilities[k].name.." "..L["Cooldown"]
						if SquawkAndAwe.db.char.durations then namestring = namestring..": " end
					end
					if SquawkAndAwe.db.char.durations then	durstring = SquawkAndAwe:DurationString(timeLeft) end
					timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
					SquawkAndAwe.frames[k][k]:SetValue(timeLeft)
					SquawkAndAwe.frames[k][k].spark:SetPoint("CENTER", SquawkAndAwe.frames[k][k], "LEFT", timeLeft * sparkscale, 0)
					SquawkAndAwe.frames[k][k].spark:Show()
					if SquawkAndAwe.db.char.bars.abilities[k].dur then
						if SquawkAndAwe.combat.abilities[k].dur then
							timeLeft = SquawkAndAwe.times[k.."Dur"] - GetTime()
						else
							timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.abilities[k].name, "buff") - GetTime()
						end
						if SquawkAndAwe.db.char.spellnames and timeLeft > 0 then
								namestring = SquawkAndAwe.combat.abilities[k].name
								if SquawkAndAwe.db.char.durations then namestring = namestring..": " end
						end
						if timeLeft < 0 then
							SquawkAndAwe.frames[k][k.."Dur"]:Hide()
						else
							if SquawkAndAwe.db.char.durations then	durstring = SquawkAndAwe:DurationString(timeLeft) end
							timeLeft = math.min(timeLeft, SquawkAndAwe.db.char.bars.MaxLen)
							SquawkAndAwe.frames[k][k.."Dur"]:Show()
							SquawkAndAwe.frames[k][k.."Dur"]:SetValue(timeLeft)
							SquawkAndAwe.frames[k][k.."Dur"].spark:SetPoint("CENTER", SquawkAndAwe.frames[k][k.."Dur"], "LEFT", timeLeft * sparkscale, 0)
							SquawkAndAwe.frames[k][k.."Dur"].spark:Show()
						end
					end
					if SquawkAndAwe.db.char.barstext then SquawkAndAwe.frames[k].text:SetText(namestring..durstring)end
				end
			end
		end
	end

	-- Handle GCD updates
	if SquawkAndAwe.actives.GCD then
		timeLeft = SquawkAndAwe:GetSpellInfo(SquawkAndAwe.combat.Moonglade.name, "cd") - GetTime()
		if timeLeft < 0 then
		    SquawkAndAwe.actives.GCD = false
		    SquawkAndAwe.frames.GCD:Hide()
		else
			SquawkAndAwe.frames.GCD.GCD:SetValue(timeLeft)
			SquawkAndAwe.frames.GCD.GCD.spark:SetPoint("CENTER",SquawkAndAwe.frames.GCD.GCD,"LEFT", timeLeft * width / 1.5, 0)
			SquawkAndAwe.frames.GCD.GCD.spark:Show()
		end
	end
end
