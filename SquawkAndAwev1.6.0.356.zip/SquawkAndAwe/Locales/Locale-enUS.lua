
local L = LibStub("AceLocale-3.0"):NewLocale("SquawkAndAwe", "enUS", true);
if not L then return end

L["About"]			= true
L["Version"]		= true

L["Cooldown"]       = true

-- Options menu
L["Reset Bars"]		= true
L["Version"]		= true
L["Move Frames"]	= true
L["Enable"]			= true
L["Disable"]		= true
L["Grow Up"]		= true

-- Help Options
L["help_reset"]		= "Resets bars frame to default values."
L["help_version"]	= "Show version information"
L["help_display"]	= "Hide or unhide the bar frames to reposition them.  When displayed, left click to drag the bars."
L["help"]			= "All options can be configured more easily using the Blizzard options menu. Press ESC and select addons then click on SquawkAndAwe to configure."
L["help_enable"]	= "Enables SquawkAndAwe."
L["help_disable"]	= "Disables SquawkAndAwe."
L["help_growup"]	= "When un-checked, SquawkAndAwe anchors at the top, and populates bars downwards. When checked, SquawkAndAwe anchors at the bottom, and populates bars upwards."

-- All
L["All Bars"]       	= true

L["Bar Width"]			= true
L["Bar Height"]     	= true
L["Bar Scale"]			= true
L["Maximum Bar Time"]	= true
L["Cooldown Bar Color"] = true
L["AutoOrder"]			= "Allow SquawkAndAwe to arrange my bars for me."
L["Order"]				= true
L["Icons"]				= true
L["Sounds"]				= true
	
	-- Media
	L["Media"]              = true

	L["Bar Texture"]		= true
	L["Border Texture"]		= true
	L["Bar Border Texture"]	= true


L["Text Display"]		= true

L["Show"] 			  	= true
L["Show Cooldown"]      = true
L["Color"]              = true
L["Sound"]				= true

-- Help All
L["help_width"]			= "The width of the status bars, in pixels."
L["help_height"]    	= "The height of the status bars, in pixels."
L["help_scale"]			= "Use this to scale bars frame. Valid scale multiplier values are 0.25 to 3"
L["help_maxlen"]    	= "Maximum length of the bars, in seconds. Any timers over this value will hold as a full bar."
L["help_cdcolor"]   	= "Color of the bars for all cooldowns (unless the associated ability has no duration)."
L["help_autoorder"]		= "When checked, SquawkAndAwe will arrange your bars. When unchecked, control the order of your bars using each bar's 'Order' option"
L["help_order"]			= "Controls the order of the bars on screen"
L["help_icons"]			= "Turn on or off spell icons"
L["help_sounds"]		= "Turn on or off sounds when procs occur, or abilities come off cooldown."
L["help_textonbars"]	= "turn on or off text displays on bars"

	-- Text Opts
    L["Text Options"]	= true
	L["Bar Text Font"]		= true
	L["Bar Text Size"]	= true
	L["Spell Names"]	= true
	L["Durations"]		= true
	
	-- Help Text Options
    L["help_spellnames"]	= "Show spell names in text display"
	L["help_durations"]		= "Show remaining duration of effect in text display"

-- Trinkets
L["Trinkets"]   = true

L["Trinket Bars"]   	= true
L["Merge Trinkets"] 	= true
L["Trinket Cooldowns"]  = true
L["Single Trinket"]		= true

-- Help Trinkets
L["help_trinketshow"]   = "Turn on or off the bars for Trinket buffs."
L["help_mergetrinkets"]	= "When checked, forces all trinkets to show on a sinlge bar."
L["help_trinketcd"]     = "When Trinkets are merged, the bar shows cooldowns instead of durations. When unmerged, displays trinket cooldowns as well as durations."
L["help_singletrinket"]	= "When checked, SAA will only allocate space for a single trinket bar."

-- Procs
L["Procs"]  = true
L["Flash"]	= true
		
	-- Eclipse
	L["Eclipse"]				= true
   	L["Lunar Eclipse Color"]	= true
    L["Solar Eclipse Color"]	= true
	L["Lunar Eclipse Sound"]	= true
	L["Solar Eclipse Sound"]	= true
    
	-- Help Eclipse
	L["help_showEclipse"]   = "Turn on or off the Eclipse Proc bar."
	L["help_eclipseCD"]     = "Turn on or off the Eclipse Cooldown bar."
	L["help_sfcolor"]       = "Color of the Lunar Eclipse Proc bar."
	L["help_wcolor"]        = "Color of the Solar Eclipse Proc."
    L["help_eclipseflash"]	= "When checked, the Eclipse Proc statusbar will flash."
    
    -- Omen
    L["Omen of Clarity"]    = true

    -- Help Omen
    L["help_omenshow"]  = "Turn on or off the Omen of Clarity bar."
    L["help_omencolor"] = "Color of the Omen of Clarity bar."
    L["help_omenflash"] = "When checked, the Omen of Clarity statusbar will flash."

    -- T84P
    L["Tier 8 4-Piece Bonus"]   = true

    -- Help T84P
   	L["help_t84pshow"]  = "Turn on or off the Elune's Wrath bar."
    L["help_t84pcolor"] = "Color of the Elune's Wrath bar."
    L["help_t84pflash"] = "When checked, the Elune's Wrath statusbar will flash."
	
	-- T102P
	L["Tier 10 2-Piece Bonus"]	= true
	
	-- Help T102P
	L["help_t102pshow"]		= "Turn on or off the Omen of Doom bar."
	L["help_t102pcolor"]	= "Color of the Omen of Doom bar."
	L["help_t102pflash"]	= "When checked, the Omen of Doom statusbar will flash."
	    
    -- PvP
	L["PvP Set Bonus"]  = true

	-- Help PVP
    L["help_pvpshow"]	= "Turn on or off the Wrath of Elune bar."
    L["help_pvpcolor"]	= "Color of the Wrath of Elune bar."
    L["help_pvpflash"]	= "When checked, the Wrath of Elune statusbar will flash."
	
	-- Idol9
	L["Tier 9 Idol"]	= true
	
	-- Help Idol9
	L["help_idol9show"]		= "Turn on or off the Blessing of the Moon Goddess bar."
	L["help_idol9color"]	= "Color of the Blessing of the Moon Goddess bar."
	
	-- Idol10
	L["Tier 10 Idol"]	= true
	
	-- Help Idol10
	L["help_idol10show"]	= "Turn on or off the Vicious bar."
	L["help_idol10color"]	= "Color of the Vicious bar."

-- Debuffs
L["Debuffs"]    	= true
L["Merge Debuffs"]  = true
L["Tick"]       	= true

-- Help Debuffs
L["help_mergedebuffs"]  = "When checked, forces all debuffs to share a single bar."

	-- Moonfire
    L["SF Combo"]       = "Starfire Combo Points"

	-- Help Moonfire
    L["help_mfshow"]    = "Turn on or off the Moonfire bar."
    L["help_mfcolor"]   = "Color of the Moonfire bar."
    L["help_mftick"]    = "Turn on or off the Moonfire tick bar."
	L["help_sfcombo"]	= "Show number of times Starfire has extended Moonfire"

	-- Help Insect
	L["help_isshow"]    = "Turn on or off the Insect Swarm bar."
	L["help_iscolor"]   = "Color of the Insect Swarm bar."
	L["help_istick"]    = "Turn on or off the Insect Swarm tick bar."

    -- Help Faerie
	L["help_ffshow"]    = "Turn on or off the Faerie Fire bar."
	L["help_ffcolor"]   = "Color of the Faerie Fire bar."
	
	-- Languish
	L["Tier 10 4-Piece Bonus"]	= true
	
	-- Help Languish
	L["help_languishshow"]	= "Turn on or off the Languish bar."
	L["help_languishcolor"]	= "Color of the Languish bar."
	L["help_languishtick"]	= "Turn on or off the Languish tick bar."

-- CC
L["Crowd Control"]  = true
L["Merge CC"]       = true

-- Help CC
L["help_mergecc"]   = "When checked, forces all cc to share a single bar."

	-- Help Roots
	L["help_rootsshow"] 	= "Turn on or off the Entangling Roots bar."
	L["help_rootscolor"]    = "Color of the Entangling Roots bar."

    -- Help Hibernate
	L["help_hibernateshow"] 	= "Turn on or off the Hibernate bar."
	L["help_hibernatecolor"]    = "Color of the Hibernate bar."

    -- Help Cyclone
	L["help_cycloneshow"] 	= "Turn on or off the Cyclone bar."
	L["help_cyclonecolor"]    = "Color of the Cyclone bar."


-- Abilities
L["Abilities"]  		= true
L["Merge Abilities"]    = true
L["Duration"]           = true

-- Help Abilities
L["help_mergeabilities"]    = "When checked, forces all abilities to share a single bar."

	-- Help Starfall
	L["help_fallshow"] 	= "Turn on or off the Starfall bar."
	L["help_fallcolor"]	= "Color of the Starfall bar."
	L["help_falldur"]	= "Turn on or off display of Starfall duration."

    -- Help Typhoon
	L["help_typhoonshow"] 	= "Turn on or off the Typhoon bar."
	L["help_typhooncolor"]  = "Color of the Typhoon bar."

    -- Help Force
	L["help_forceshow"] 	= "Turn on or off the Force of Nature bar."
	L["help_forcecolor"]    = "Color of the Foirce of Nature bar."
	L["help_forcedur"]		= "Turn on or off display of Force of Nature duration."

    -- Help Innervate
	L["help_innervshow"] 	= "Turn on or off the Innervate bar."
	L["help_innervcolor"]	= "Color of the Innervate bar."
	L["help_innervdur"]		= "Turn on or off display of Innervate duration."

    -- Help Starfall
	L["help_barkshow"]	= "Turn on or off the Barkskin bar."
	L["help_barkcolor"]	= "Color of the Barkskin bar."
	L["help_barkdur"]	= "Turn on or off display of Barkskin duration."

-- GCD
L["GCD"]			= "Global Cooldown"
L["help_gcd"]		= "Turn on or off the Global Cooldown bar."
L["help_gcdcolor"]  = "Color of the GCD bar."
