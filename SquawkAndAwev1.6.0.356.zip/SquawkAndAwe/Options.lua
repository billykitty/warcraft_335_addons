local L		= LibStub("AceLocale-3.0"):GetLocale("SquawkAndAwe")
local media	= LibStub:GetLibrary("LibSharedMedia-3.0");

function SquawkAndAwe:GetOptions()
	local options = { 
		name		= "SquawkAndAwe",
		handler		= SquawkAndAwe,
		type		= 'group',
		childGroups	='tree',
		args	= {
		    resetbars	= {
				type	= 'execute',
				name	= L["Reset Bars"],
				desc	= L["help_reset"],
				func	= "ResetBars",
				order	= 1,
			},
			version	= {
				type	= 'execute',
				name	= L["Version"],
				desc	= L["help_version"],
				func	= "DisplayVersion",
				order	= 2,
			},
			moveframes	= {
				type	= 'toggle',
				name	= L["Move Frames"],
				desc	= L["help_display"],
				get		= function () return self.db.char.barshow end,
				set		= "ShowHideBars",
				order	= 3,
			},
			enable			= {
				type		= 'execute',
				name		= L["Enable"],
				desc		= L["help_enable"],
				guiHidden	= true,
				func		= function () SquawkAndAwe:Enable() SquawkAndAwe:Print("SAA Enabled") end,
				order		= 4,
			},
			disable			= {
				type		= 'execute',
				name		= L["Disable"],
				desc		= L["help_disable"],
				guiHidden	= true,
				func		= function () SquawkAndAwe:Print("SAA Disabled") SquawkAndAwe:Disable() end,
				order		= 5,
			},
			help	= {
				type		= 'description',
				name		= L["help"],
				guiHidden	= true,
				order		= 6,
			},
			all		= {
				type	= 'group',
				name	= L["All Bars"],
				order	= 7,
				args	= {
					width	= {
						type	= 'range',
						name	= L["Bar Width"],
						desc	= L["help_width"],
						min		= 100,
						max		= 500,
						step	= 10,
						get		= function () return SquawkAndAwe.db.char.fWidth end,
						set		= function (info,newValue)
									self.db.char.fWidth	= newValue
									self:RedrawFrames()
									end,
						order	= 1,
					},
					height	= {
						type	= 'range',
						name	= L["Bar Height"],
						desc	= L["help_height"],
						min		= 10,
						max		= 100,
						step    = 5,
						get		= function () return self.db.char.barHeight end,
						set		= function (info, newValue)
									self.db.char.barHeight = newValue
									self:RedrawFrames()
									end,
						order	= 2,
					},
					scale	= {
						type	= 'range',
						name	= L["Bar Scale"],
						desc	= L["help_scale"],
						min		= 0.25,
						max		= 3.00,
						step	= 0.05,
						get		= function () return self.db.char.scale	end,
						set		= function (info,newValue)
									self.db.char.scale	= newValue
									self.BaseFrame:SetScale(self.db.char.scale)
									end,
						order	= 3,
					},
					maxlen	= {
						type	= 'range',
						name	= L["Maximum Bar Time"],
						desc	= L["help_maxlen"],
						min		= 10,
						max		= 60,
						step    = 1,
						get		= function () return self.db.char.bars.MaxLen end,
						set		= function (info, newValue)
									self.db.char.bars.MaxLen = newValue
									self:RedrawFrames()
									end,
						order	= 4,
					},
					autoorder	={
						type	= 'toggle',
						name	= L["AutoOrder"],
						desc	= L["help_autoorder"],
						get		= function () return self.db.char.bars.autoorder end,
						set		= function ()
									self.db.char.bars.autoorder = not self.db.char.bars.autoorder
									self:RedrawFrames()
									end,
						order	= 5		
					},
					growup	= {
						type	= 'toggle',
						name	= L["Grow Up"],
						desc	= L["help_growup"],
						get		= function () return self.db.char.bars.growup end,
						set		= function ()
										self.db.char.bars.growup	= not self.db.char.bars.growup
										--[[if self.db.char.bars.growup then
											self.db.char.point = "BOTTOM"
											self.db.char.yOffset = self.db.char.yOffset + self.BaseFrame:GetHeight()
										else
											self.db.char.point = "TOP"
											self.db.char.yOffset = self.db.char.yOffset - self.BaseFrame:GetHeight()
										end--]]
										self:RedrawFrames()
									end,
						order	= 6
					},
					cdcolor	= {
						type	= 'color',
						name	= L["Cooldown Bar Color"],
						desc	= L["help_cdcolor"],
						get		= function ()
									local colors = self.db.char.bars.cdcolor
									return colors.r, colors.g, colors.b, colors.a
									end,
						set		= function (info, r, g, b, a)
									self.db.char.bars.cdcolor.r = r
									self.db.char.bars.cdcolor.g = g
                                    self.db.char.bars.cdcolor.b = b
                                    self.db.char.bars.cdcolor.a = a
                                    end,
						hasAlpha	= true,
						order	= 7,
					},
					icons	= {
						type	= 'toggle',
						name	= L["Icons"],
						desc	= L["help_icons"],
						get		= function () return self.db.char.icons end,
						set		= function ()
									self.db.char.icons = not self.db.char.icons
									self:RedrawFrames()
									end,
						order	= 8,
					},
					sounds	= {
						type	= 'toggle',
						name	= L["Sounds"],
						desc	= L["help_sounds"],
						get		= function () return self.db.char.bars.procs.sounds end,
						set		= function ()
									self.db.char.bars.procs.sounds	= not self.db.char.bars.procs.sounds
									end,
						order	= 9,
					},
					media = {
					    name	= L["Media"],
						type	= 'group',
						order	= 10,
						args	= {
							texture	= {
								type	= 'select',
								name	= L["Bar Texture"],
								get		= function () return self.db.char.texture end,
								set		= "SetBarTexture",
								values	= self.textures,
								order	= 1,
							},
							border	= {
								type	= 'select',
								name	= L["Border Texture"],
								get		= function () return self.db.char.border end,
								set		= "SetBorderTexture",
								values	= self.borders,
								order	= 2,
							},
							barborder	= {
								type	= 'select',
								name	= L["Bar Border Texture"],
								get		= function () return self.db.char.barborder end,
								set		= "SetBarBorderTexture",
								values	= self.borders,
								order	= 3,
							},
	  					},
					},
					showtext	= {
						type	= 'toggle',
						name	= L["Text Display"],
						desc	= L["help_textonbars"],
						get		= function () return self.db.char.barstext end,
						set		= function ()
									self.db.char.barstext = not self.db.char.barstext
									self:RedrawFrames()
									end,
						order	= 11,
					},
					textopts	= {
						name	= L["Text Options"],
						type	= 'group',
						order	= 12,
						args	= {
							barfont	= {
								type	= 'select',
								name	= L["Bar Text Font"],
								get		= function () return self.db.char.barfont end,
								set		= function    (info, newValue)
											self.db.char.barfont	= newValue
											self:RedrawFrames()
											end,
								values	= self.fonts,
								order	= 1,
							},
							barfontsize	= {
								type	= 'range',
								name	= L["Bar Text Size"],
								min		= 6,
								max		= 32,
								step	= 1,
								get		= function () return self.db.char.barfontsize end,
								set		= function (info, newValue)
											self.db.char.barfontsize	= newValue
											self:RedrawFrames()
											end,
								order	= 2,
							},
							names	= {
								type	= 'toggle',
								name	= L["Spell Names"],
								desc	= L["help_spellnames"],
								get		= function () return self.db.char.spellnames end,
								set		= function () self.db.char.spellnames	= not self.db.char.spellnames end,
								order	= 3,
							},
							durations	= {
								type	= 'toggle',
								name	= L["Durations"],
								desc	= L["help_durations"],
								get		= function () return self.db.char.durations end,
								set		= function () self.db.char.durations = not self.db.char.durations end,
								order	= 4,
							},
						}, -- textopts.args
					}, -- all.textopts
				}, -- all.args
			}, -- options.all
			trinkets = {
				type	= 'group',
				name	= L["Trinkets"],
				order	= 8,
				args	= {
					trinketshow	= {
						type	= 'toggle',
						name	= L["Trinket Bars"],
						desc	= L["help_trinketshow"],
						get		= function () return self.db.char.bars.trinketshow end,
						set		= function ()
									self.db.char.bars.trinketshow = not self.db.char.bars.trinketshow
									self:RedrawFrames()
									end,
						order	= 1,
					},
					mergetrinkets	= {
						type	= 'toggle',
						name	= L["Merge Trinkets"],
						desc	= L["help_mergetrinkets"],
						get		= function () return self.db.char.bars.mergetrinkets end,
						set		= function ()
									self.db.char.bars.mergetrinkets = not self.db.char.bars.mergetrinkets
									self:RedrawFrames()
									end,
						order	= 2,
					},
					trinketcd	= {
						type	= 'toggle',
						name	= L["Trinket Cooldowns"],
						desc	= L["help_trinketcd"],
						get		= function () return self.db.char.bars.trinketcd end,
						set		= function ()
									self.db.char.bars.trinketcd = not self.db.char.bars.trinketcd
									self:RedrawFrames()
									end,
						order	= 3,
					},
					singletrinket	= {
						type	= 'toggle',
						name	= L["Single Trinket"],
						desc	= L["help_singletrinket"],
						get		= function () return self.db.char.bars.singletrinket end,
						set		= function ()
									self.db.char.bars.singletrinket = not self.db.char.bars.singletrinket
									self:RedrawFrames()
									end,
						order	= 4,
					}, -- trinkets.singletrinket
				}, -- trinkets.args
			},	-- bars.trinkets
			procs	= {
				type	= 'group',
				name	= L["Procs"],
				order	= 9,
				childGroups	= 'tab',
				args	= {
					eclipse	= {
						type	= 'group',
						name	= L["Eclipse"],
						order	= 2,
						args	= {
							show	= {
								type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_showEclipse"],
								get		= function () return self.db.char.bars.procs.Eclipse.show end,
								set		= function ()
											self.db.char.bars.procs.Eclipse.show = not self.db.char.bars.procs.Eclipse.show
											self:RedrawFrames()
                                                  end,
								order	= 1,
							},
							cd	= {
								type	= 'toggle',
								name	= L["Show Cooldown"],
								desc	= L["help_eclipseCD"],
								get		= function () return self.db.char.bars.procs.Eclipse.cd end,
								set		= function ()
											self.db.char.bars.procs.Eclipse.cd = not self.db.char.bars.procs.Eclipse.cd
											self:RedrawFrames()
											end,
								order	= 2,
							},
							color	= {
								type		= 'color',
								name		= L["Lunar Eclipse Color"],
								desc		= L["help_sfcolor"],
								get			= function ()
												local colors = self.db.char.bars.procs.Eclipse.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.Eclipse.color.r = r
												self.db.char.bars.procs.Eclipse.color.g = g
												self.db.char.bars.procs.Eclipse.color.b = b
												self.db.char.bars.procs.Eclipse.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 3,
							},
							wcolor	= {
								type		= 'color',
								name		= L["Solar Eclipse Color"],
								desc		= L["help_wcolor"],
								get			= function ()
												local colors = self.db.char.bars.procs.Eclipsew.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.Eclipsew.color.r = r
												self.db.char.bars.procs.Eclipsew.color.g = g
												self.db.char.bars.procs.Eclipsew.color.b = b
												self.db.char.bars.procs.Eclipsew.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 4,
							},
							sound	= {
								type	= 'select',
								name	= L["Lunar Eclipse Sound"],
								get		= function () return self.db.char.bars.procs.Eclipse.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.Eclipse.sound	= newValue
											end,
								values	= self.sounds,
								order	= 5,
							},
							wsound	= {
								type	= 'select',
								name	= L["Solar Eclipse Sound"],
								get		= function () return self.db.char.bars.procs.Eclipsew.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.Eclipsew.sound	= newValue
											self:RedrawFrames()
											end,
								values	= self.sounds,
								order	= 6,
							},
							flash		= {
								type	= 'toggle',
								name	= L["Flash"],
								desc	= L["help_eclipseflash"],
								get		= function () return self.db.char.bars.procs.Eclipse.flash end,
								set		= function () self.db.char.bars.procs.Eclipse.flash = not self.db.char.bars.procs.Eclipse.flash end,
								order	= 7,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.procs.Eclipse.order end,
								set		= function (info,newValue)
											self.db.char.bars.procs.Eclipse.order	= newValue
											self:RedrawFrames()
											end,
								order	= 8,
							},
						}, -- eclipse.args
					}, -- procs.eclipse
					omen	= {
						type	= 'group',
						name	= L["Omen of Clarity"],
						order   = 3,
						args    = {
							show    = {
								type    = 'toggle',
								name    = L["Show"],
								desc    = L["help_omenshow"],
								get		= function () return self.db.char.bars.procs.Omen.show end,
								set		= function ()
											self.db.char.bars.procs.Omen.show = not self.db.char.bars.procs.Omen.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
							color   = {
                                      type		= 'color',
								name		= L["Color"],
								desc		= L["help_omencolor"],
								get			= function ()
												local colors = self.db.char.bars.procs.Omen.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.Omen.color.r = r
												self.db.char.bars.procs.Omen.color.g = g
												self.db.char.bars.procs.Omen.color.b = b
												self.db.char.bars.procs.Omen.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.procs.Omen.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.Omen.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							flash   = {
                                type	= 'toggle',
								name	= L["Flash"],
								desc	= L["help_omenflash"],
          						get		= function () return self.db.char.bars.procs.Omen.flash end,
								set		= function ()
											self.db.char.bars.procs.Omen.flash = not self.db.char.bars.procs.Omen.flash
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.procs.Omen.order end,
								set		= function (info,newValue)
											self.db.char.bars.procs.Omen.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- omen.args
					}, -- procs.omen
					t84p    = {
						type    = 'group',
						name    = L["Tier 8 4-Piece Bonus"],
						order   = 4,
						args    = {
            				show    = {
								type    = 'toggle',
								name    = L["Show"],
								desc    = L["help_t84pshow"],
								get		= function () return self.db.char.bars.procs.T84P.show end,
								set		= function ()
											self.db.char.bars.procs.T84P.show = not self.db.char.bars.procs.T84P.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
							color   = {
                                type		= 'color',
								name		= L["Color"],
								desc		= L["help_t84pcolor"],
								get			= function ()
												local colors = self.db.char.bars.procs.T84P.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.T84P.color.r = r
												self.db.char.bars.procs.T84P.color.g = g
												self.db.char.bars.procs.T84P.color.b = b
												self.db.char.bars.procs.T84P.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.procs.T84P.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.T84P.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							flash   = {
                                type	= 'toggle',
								name	= L["Flash"],
								desc	= L["help_t84pflash"],
          						get		= function () return self.db.char.bars.procs.T84P.flash end,
								set		= function ()
											self.db.char.bars.procs.T84P.flash = not self.db.char.bars.procs.T84P.flash
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.procs.T84P.order end,
								set		= function (info,newValue)
											self.db.char.bars.procs.T84P.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- t48p.args
					}, -- procs.t48p
					t102p	= {
						type	= 'group',
						name	= L["Tier 10 2-Piece Bonus"],
						order   = 5,
						args    = {
							show    = {
								type    = 'toggle',
								name    = L["Show"],
								desc    = L["help_t102pshow"],
								get		= function () return self.db.char.bars.procs.T102P.show end,
								set		= function ()
											self.db.char.bars.procs.T102P.show = not self.db.char.bars.procs.T102P.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
							color   = {
                                      type		= 'color',
								name		= L["Color"],
								desc		= L["help_t102pcolor"],
								get			= function ()
												local colors = self.db.char.bars.procs.T102P.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.T102P.color.r = r
												self.db.char.bars.procs.T102P.color.g = g
												self.db.char.bars.procs.T102P.color.b = b
												self.db.char.bars.procs.T102P.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.procs.T102P.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.T102P.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							flash   = {
                                type	= 'toggle',
								name	= L["Flash"],
								desc	= L["help_t102pflash"],
          						get		= function () return self.db.char.bars.procs.T102P.flash end,
								set		= function ()
											self.db.char.bars.procs.T102P.flash = not self.db.char.bars.procs.T102P.flash
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.procs.T102P.order end,
								set		= function (info,newValue)
											self.db.char.bars.procs.T102P.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- t102p.args
					}, -- procs.t102p
					pvp = {
					    type    = 'group',
						name    = L["PvP Set Bonus"],
						order   = 6,
						args    = {
            				show    = {
								type    = 'toggle',
								name    = L["Show"],
								desc    = L["help_pvpshow"],
								get		= function () return self.db.char.bars.procs.PVP.show end,
								set		= function ()
											self.db.char.bars.procs.PVP.show = not self.db.char.bars.procs.PVP.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
							color   = {
                                type		= 'color',
								name		= L["Color"],
								desc		= L["help_pvpcolor"],
								get			= function ()
												local colors = self.db.char.bars.procs.PVP.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.PVP.color.r = r
												self.db.char.bars.procs.PVP.color.g = g
												self.db.char.bars.procs.PVP.color.b = b
												self.db.char.bars.procs.PVP.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.procs.PVP.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.PVP.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							flash   = {
                                type	= 'toggle',
								name	= L["Flash"],
								desc	= L["help_pvpflash"],
       							get		= function () return self.db.char.bars.procs.PVP.flash end,
								set		= function ()
											self.db.char.bars.procs.PVP.flash = not self.db.char.bars.procs.PVP.flash
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.procs.PVP.order end,
								set		= function (info,newValue)
											self.db.char.bars.procs.PVP.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- pvp.args
					}, -- procs.pvp
					idol9	= {
						type	= 'group',
						name	= L["Tier 9 Idol"],
						order   = 7,
						args    = {
							show    = {
								type    = 'toggle',
								name    = L["Show"],
								desc    = L["help_idol9show"],
								get		= function () return self.db.char.bars.procs.Idol9.show end,
								set		= function ()
											self.db.char.bars.procs.Idol9.show = not self.db.char.bars.procs.Idol9.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
							color   = {
                                type		= 'color',
								name		= L["Color"],
								desc		= L["help_idol9color"],
								get			= function ()
												local colors = self.db.char.bars.procs.Idol9.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.Idol9.color.r = r
												self.db.char.bars.procs.Idol9.color.g = g
												self.db.char.bars.procs.Idol9.color.b = b
												self.db.char.bars.procs.Idol9.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.procs.Idol9.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.Idol9.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							order	= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.procs.Idol9.order end,
								set		= function (info,newValue)
											self.db.char.bars.procs.Idol9.order	= newValue
											self:RedrawFrames()
											end,
								order	= 4,
							},
						}, -- idol9.args
					}, -- procs.idol9
					idol10	= {
						type	= 'group',
						name	= L["Tier 10 Idol"],
						order   = 7,
						args    = {
							show    = {
								type    = 'toggle',
								name    = L["Show"],
								desc    = L["help_idol10show"],
								get		= function () return self.db.char.bars.procs.Idol10.show end,
								set		= function ()
											self.db.char.bars.procs.Idol10.show = not self.db.char.bars.procs.Idol10.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
							color   = {
                                type		= 'color',
								name		= L["Color"],
								desc		= L["help_idol10color"],
								get			= function ()
												local colors = self.db.char.bars.procs.Idol10.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.procs.Idol10.color.r = r
												self.db.char.bars.procs.Idol10.color.g = g
												self.db.char.bars.procs.Idol10.color.b = b
												self.db.char.bars.procs.Idol10.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.procs.Idol10.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.procs.Idol10.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							order	= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.procs.Idol10.order end,
								set		= function (info,newValue)
											self.db.char.bars.procs.Idol10.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- idol10.args
					}, -- procs.idol10
				}, -- procs.args
			}, -- bars.procs
			debuffs = {
			    type	= 'group',
				name	= L["Debuffs"],
				order	= 10,
				childGroups	= 'tab',
				args	= {
					mergedebuffs    = {
					    type    = 'toggle',
					    name    = L["Merge Debuffs"],
						desc    = L["help_mergedebuffs"],
						get     = function () return self.db.char.bars.mergedebuffs end,
						set     = function ()
						            self.db.char.bars.mergedebuffs = not self.db.char.bars.mergedebuffs
						            self:RedrawFrames()
						            end,
						order   = 1,
					},
					moonfire    = {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.debuffs.Moonfire.name,
						order   = 2,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_mfshow"],
								get		= function () return self.db.char.bars.debuffs.Moonfire.show end,
								set		= function ()
											self.db.char.bars.debuffs.Moonfire.show	= not self.db.char.bars.debuffs.Moonfire.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_mfcolor"],
								get			= function ()
												local colors = self.db.char.bars.debuffs.Moonfire.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.debuffs.Moonfire.color.r = r
												self.db.char.bars.debuffs.Moonfire.color.g = g
												self.db.char.bars.debuffs.Moonfire.color.b = b
												self.db.char.bars.debuffs.Moonfire.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							tick   = {
                                type	= 'toggle',
								name	= L["Tick"],
								desc	= L["help_mftick"],
        						get		= function () return self.db.char.bars.debuffs.Moonfire.tick end,
								set		= function ()
											self.db.char.bars.debuffs.Moonfire.tick = not self.db.char.bars.debuffs.Moonfire.tick
											self:RedrawFrames()
											end,
								order	= 3,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.debuffs.Moonfire.order end,
								set		= function (info,newValue)
											self.db.char.bars.debuffs.Moonfire.order	= newValue
											self:RedrawFrames()
											end,
								order	= 4,
							},
							sfcombos	= {
								type	= 'toggle',
								name	= L["SF Combo"],
								desc	= L["help_sfcombo"],
								get		= function () return self.db.char.sfcomboshow end,
								set		= function ()
											self.db.char.sfcomboshow    = not self.db.char.sfcomboshow
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- moonfire.args
					}, -- debuffs.moonfire
       				--[[insect    = {
                   	    type    = 'group',
						name    = SquawkAndAwe.combat.debuffs.Insect.name,
						order   = 3,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_isshow"],
								get		= function () return self.db.char.bars.debuffs.Insect.show end,
								set		= function ()
											self.db.char.bars.debuffs.Insect.show = not self.db.char.bars.debuffs.Insect.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
            	                type		= 'color',
								name		= L["Color"],
								desc		= L["help_iscolor"],
								get			= function ()
												local colors = self.db.char.bars.debuffs.Insect.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.debuffs.Insect.color.r = r
												self.db.char.bars.debuffs.Insect.color.g = g
												self.db.char.bars.debuffs.Insect.color.b = b
												self.db.char.bars.debuffs.Insect.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							tick   = {
                       	        type	= 'toggle',
								name	= L["Tick"],
								desc	= L["help_istick"],
          						get		= function () return self.db.char.bars.debuffs.Insect.tick end,
								set		= function ()
											self.db.char.bars.debuffs.Insect.tick = not self.db.char.bars.debuffs.Insect.tick
											self:RedrawFrames()
											end,
								order	= 3,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.debuffs.Insect.order end,
								set		= function (info,newValue)
											self.db.char.bars.debuffs.Insect.order	= newValue
											self:RedrawFrames()
											end,
								order	= 4,
							},
						}, -- insect.args
					}, -- debuffs.insect --]]
					faerie    = {
        	            type    = 'group',
						name    = SquawkAndAwe.combat.debuffs.Faerie.name,
						order   = 4,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_ffshow"],
								get		= function () return self.db.char.bars.debuffs.Faerie.show end,
								set		= function ()
											self.db.char.bars.debuffs.Faerie.show = not self.db.char.bars.debuffs.Faerie.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
                                type		= 'color',
								name		= L["Color"],
								desc		= L["help_ffcolor"],
								get			= function ()
												local colors = self.db.char.bars.debuffs.Faerie.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.debuffs.Faerie.color.r = r
												self.db.char.bars.debuffs.Faerie.color.g = g
												self.db.char.bars.debuffs.Faerie.color.b = b
												self.db.char.bars.debuffs.Faerie.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.debuffs.Faerie.order end,
								set		= function (info,newValue)
											self.db.char.bars.debuffs.Faerie.order	= newValue
											self:RedrawFrames()
											end,
								order	= 3,
							},
						}, -- faerie.args
					}, -- debuffs.faerie
					languish	= {
						type    = 'group',
						name    = L["Tier 10 4-Piece Bonus"],
						order   = 5,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_languishshow"],
								get		= function () return self.db.char.bars.debuffs.Languish.show end,
								set		= function ()
											self.db.char.bars.debuffs.Languish.show	= not self.db.char.bars.debuffs.Languish.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_languishcolor"],
								get			= function ()
												local colors = self.db.char.bars.debuffs.Languish.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.debuffs.Languish.color.r = r
												self.db.char.bars.debuffs.Languish.color.g = g
												self.db.char.bars.debuffs.Languish.color.b = b
												self.db.char.bars.debuffs.Languish.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							tick   = {
                                type	= 'toggle',
								name	= L["Tick"],
								desc	= L["help_languishtick"],
        						get		= function () return self.db.char.bars.debuffs.Languish.tick end,
								set		= function ()
											self.db.char.bars.debuffs.Languish.tick = not self.db.char.bars.debuffs.Languish.tick
											self:RedrawFrames()
											end,
								order	= 3,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.debuffs.Languish.order end,
								set		= function (info,newValue)
											self.db.char.bars.debuffs.Languish.order	= newValue
											self:RedrawFrames()
											end,
								order	= 4,
							},
						}, -- languish.args
					}, -- debuffs.languish
				}, -- debuffs.args
			}, -- options.debuffs
			cc = {
			    type	= 'group',
				name	= L["Crowd Control"],
				order	= 11,
				childGroups	= 'tab',
				args	= {
				    mergecc    = {
					    type    = 'toggle',
					    name    = L["Merge CC"],
						desc    = L["help_mergecc"],
						get     = function () return self.db.char.bars.mergecc end,
						set     = function ()
						            self.db.char.bars.mergecc = not self.db.char.bars.mergecc
						            self:RedrawFrames()
						            end,
						order   = 1,
					},
					roots    = {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.cc.Roots.name,
						order   = 2,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_rootsshow"],
								get		= function () return self.db.char.bars.cc.Roots.show end,
								set		= function ()
											self.db.char.bars.cc.Roots.show	= not self.db.char.bars.cc.Roots.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_rootscolor"],
								get			= function ()
												local colors = self.db.char.bars.cc.Roots.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.cc.Roots.color.r = r
												self.db.char.bars.cc.Roots.color.g = g
												self.db.char.bars.cc.Roots.color.b = b
												self.db.char.bars.cc.Roots.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.cc.Roots.order end,
								set		= function (info,newValue)
											self.db.char.bars.cc.Roots.order	= newValue
											self:RedrawFrames()
											end,
								order	= 3,
							},							
						}, -- roots.args
					}, -- cc.roots
					hibernate    = {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.cc.Hibernate.name,
						order   = 3,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_hibernateshow"],
								get		= function () return self.db.char.bars.cc.Hibernate.show end,
								set		= function ()
											self.db.char.bars.cc.Hibernate.show	= not self.db.char.bars.cc.Hibernate.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_hibernatecolor"],
								get			= function ()
												local colors = self.db.char.bars.cc.Hibernate.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.cc.Hibernate.color.r = r
												self.db.char.bars.cc.Hibernate.color.g = g
												self.db.char.bars.cc.Hibernate.color.b = b
												self.db.char.bars.cc.Hibernate.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.cc.Hibernate.order end,
								set		= function (info,newValue)
											self.db.char.bars.cc.Hibernate.order	= newValue
											self:RedrawFrames()
											end,
								order	= 3,
							},
						}, -- hibernate.args
					}, -- cc.hibernate
					cyclone    = {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.cc.Cyclone.name,
						order   = 4,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_cycloneshow"],
								get		= function () return self.db.char.bars.cc.Cyclone.show end,
								set		= function ()
											self.db.char.bars.cc.Cyclone.show	= not self.db.char.bars.cc.Cyclone.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_cyclonecolor"],
								get			= function ()
												local colors = self.db.char.bars.cc.Cyclone.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.cc.Cyclone.color.r = r
												self.db.char.bars.cc.Cyclone.color.g = g
												self.db.char.bars.cc.Cyclone.color.b = b
												self.db.char.bars.cc.Cyclone.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.cc.Cyclone.order end,
								set		= function (info,newValue)
											self.db.char.bars.cc.Cyclone.order	= newValue
											self:RedrawFrames()
											end,
								order	= 3,
							},
						}, -- cyclone.args
					}, -- cc.cyclone
				}, -- cc.args
			}, -- options.cc
			abilities = {
			    type	= 'group',
				name	= L["Abilities"],
				order	= 12,
				childGroups	= 'tab',
				args	= {
                    mergecc    = {
					    type    = 'toggle',
					    name    = L["Merge Abilities"],
						desc    = L["help_mergeabilities"],
						get     = function () return self.db.char.bars.mergeabilities end,
						set     = function ()
						            self.db.char.bars.mergeabilities = not self.db.char.bars.mergeabilities
						            self:RedrawFrames()
						            end,
						order   = 1,
					},
                    starfall	= {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.abilities.Starfall.name,
						order   = 2,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_fallshow"],
								get		= function () return self.db.char.bars.abilities.Starfall.show end,
								set		= function ()
											self.db.char.bars.abilities.Starfall.show	= not self.db.char.bars.abilities.Starfall.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_fallcolor"],
								get			= function ()
												local colors = self.db.char.bars.abilities.Starfall.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.abilities.Starfall.color.r = r
												self.db.char.bars.abilities.Starfall.color.g = g
												self.db.char.bars.abilities.Starfall.color.b = b
												self.db.char.bars.abilities.Starfall.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.abilities.Starfall.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.abilities.Starfall.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							dur = {
							    type	= 'toggle',
								name	= L["Duration"],
								desc	= L["help_falldur"],
								get		= function () return self.db.char.bars.abilities.Starfall.dur end,
								set		= function ()
											self.db.char.bars.abilities.Starfall.dur	= not self.db.char.bars.abilities.Starfall.dur
											self:RedrawFrames()
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.abilities.Starfall.order end,
								set		= function (info,newValue)
											self.db.char.bars.abilities.Starfall.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- starfall.args
					}, -- abilities.starfall
					typhoon	= {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.abilities.Typhoon.name,
						order   = 3,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_typhoonshow"],
								get		= function () return self.db.char.bars.abilities.Typhoon.show end,
								set		= function ()
											self.db.char.bars.abilities.Typhoon.show	= not self.db.char.bars.abilities.Typhoon.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_typhooncolor"],
								get			= function ()
												local colors = self.db.char.bars.abilities.Typhoon.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.abilities.Typhoon.color.r = r
												self.db.char.bars.abilities.Typhoon.color.g = g
												self.db.char.bars.abilities.Typhoon.color.b = b
												self.db.char.bars.abilities.Typhoon.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.abilities.Typhoon.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.abilities.Typhoon.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.abilities.Typhoon.order end,
								set		= function (info,newValue)
											self.db.char.bars.abilities.Typhoon.order	= newValue
											self:RedrawFrames()
											end,
								order	= 4,
							},
						}, -- typhoon.args
					}, -- abilities.typhoon
					force	= {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.abilities.Force.name,
						order   = 4,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_forceshow"],
								get		= function () return self.db.char.bars.abilities.Force.show end,
								set		= function ()
											self.db.char.bars.abilities.Force.show	= not self.db.char.bars.abilities.Force.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_forcecolor"],
								get			= function ()
												local colors = self.db.char.bars.abilities.Force.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.abilities.Force.color.r = r
												self.db.char.bars.abilities.Force.color.g = g
												self.db.char.bars.abilities.Force.color.b = b
												self.db.char.bars.abilities.Force.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.abilities.Force.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.abilities.Force.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							dur = {
							    type	= 'toggle',
								name	= L["Duration"],
								desc	= L["help_forcedur"],
								get		= function () return self.db.char.bars.abilities.Force.dur end,
								set		= function ()
											self.db.char.bars.abilities.Force.dur	= not self.db.char.bars.abilities.Force.dur
											self:RedrawFrames()
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.abilities.Force.order end,
								set		= function (info,newValue)
											self.db.char.bars.abilities.Force.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- force.args
					}, -- abilities.force
					innervate	= {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.abilities.Innervate.name,
						order   = 5,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_innervshow"],
								get		= function () return self.db.char.bars.abilities.Innervate.show end,
								set		= function ()
											self.db.char.bars.abilities.Innervate.show	= not self.db.char.bars.abilities.Innervate.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_innervcolor"],
								get			= function ()
												local colors = self.db.char.bars.abilities.Innervate.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.abilities.Innervate.color.r = r
												self.db.char.bars.abilities.Innervate.color.g = g
												self.db.char.bars.abilities.Innervate.color.b = b
												self.db.char.bars.abilities.Innervate.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.abilities.Innervate.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.abilities.Innervate.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							dur = {
							    type	= 'toggle',
								name	= L["Duration"],
								desc	= L["help_innervdur"],
								get		= function () return self.db.char.bars.abilities.Innervate.dur end,
								set		= function ()
											self.db.char.bars.abilities.Innervate.dur	= not self.db.char.bars.abilities.Innervate.dur
											self:RedrawFrames()
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.abilities.Innervate.order end,
								set		= function (info,newValue)
											self.db.char.bars.abilities.Innervate.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- innervate.args
					}, -- abilities.innervate
					barkskin	= {
               		    type    = 'group',
						name    = SquawkAndAwe.combat.abilities.Barkskin.name,
						order   = 6,
						args    = {
							show    = {
							    type	= 'toggle',
								name	= L["Show"],
								desc	= L["help_barkshow"],
								get		= function () return self.db.char.bars.abilities.Barkskin.show end,
								set		= function ()
											self.db.char.bars.abilities.Barkskin.show	= not self.db.char.bars.abilities.Barkskin.show
											self:RedrawFrames()
											end,
								order	= 1,
							},
                            color   = {
           	                    type		= 'color',
								name		= L["Color"],
								desc		= L["help_barkcolor"],
								get			= function ()
												local colors = self.db.char.bars.abilities.Barkskin.color
												return colors.r, colors.g, colors.b, colors.a
												end,
								set			= function (info,r,g,b,a)
												self.db.char.bars.abilities.Barkskin.color.r = r
												self.db.char.bars.abilities.Barkskin.color.g = g
												self.db.char.bars.abilities.Barkskin.color.b = b
												self.db.char.bars.abilities.Barkskin.color.a = a
												self:RedrawFrames()
												end,
								hasAlpha	= true,
								order		= 2,
							},
							sound	= {
								type	= 'select',
								name	= L["Sound"],
								get		= function () return self.db.char.bars.abilities.Barkskin.sound end,
								set		= function    (info, newValue)
											self.db.char.bars.abilities.Barkskin.sound	= newValue
											end,
								values	= self.sounds,
								order	= 3,
							},
							dur = {
							    type	= 'toggle',
								name	= L["Duration"],
								desc	= L["help_barkdur"],
								get		= function () return self.db.char.bars.abilities.Barkskin.dur end,
								set		= function ()
											self.db.char.bars.abilities.Barkskin.dur	= not self.db.char.bars.abilities.Barkskin.dur
											self:RedrawFrames()
											end,
								order	= 4,
							},
							order		= {
								type	= 'range',
								name	= L["Order"],
								desc	= L["help_order"],
								min		= 1,
								max		= 10,
								step	= 1,
								get		= function () return self.db.char.bars.abilities.Barkskin.order end,
								set		= function (info,newValue)
											self.db.char.bars.abilities.Barkskin.order	= newValue
											self:RedrawFrames()
											end,
								order	= 5,
							},
						}, -- barkskin.args
					}, -- abilities.barkskin
				}, -- abilities.args
			}, -- options.abilities
			gcd	= {
				type	= 'group',
				name	= L["GCD"],
				order	= 13,
				childGroups	= 'tab',
				args = {
				    show    = {
						type	= 'toggle',
						name	= L["Show"],
						desc	= L["help_gcd"],
						get		= function () return self.db.char.bars.GCD.show end,
						set		= function ()
									self.db.char.bars.GCD.show = not self.db.char.bars.GCD.show
									self:RedrawFrames()
									end,
						order	= 1,
					},
					color   = {
					    type		= 'color',
						name		= L["Color"],
						desc		= L["help_gcdcolor"],
						get			= function ()
										local colors = self.db.char.bars.GCD.color
										return colors.r, colors.g, colors.b, colors.a
										end,
						set			= function (info,r,g,b,a)
										self.db.char.bars.GCD.color.r = r
										self.db.char.bars.GCD.color.g = g
										self.db.char.bars.GCD.color.b = b
										self.db.char.bars.GCD.color.a = a
										self:RedrawFrames()
										end,
						hasAlpha	= true,
						order		= 2,
					},
				}, -- GCD.args
			}, -- options.GCD
		}, -- options.args
	} -- options
	return options
end

-- Media
function SquawkAndAwe:SetBarTexture(info, newValue)
	local barTexture = media:Fetch('statusbar', newValue)
	if barTexture then
		self.db.char.texture = newValue
		self:RedrawFrames()
	elseif self.db.char.debug then
		self:Print("border texture not found. Trying to set "..self.db.char.border)
	end
end

function SquawkAndAwe:SetBorderTexture(info, newValue)
	local newTexture	= media:Fetch("border", newValue)
	if newTexture then
		self.db.char.border	= newValue
		self:RedrawFrames()
	elseif self.db.char.debug then
		self:Print("border texture not found. Trying to set "..self.db.char.border)
	end
end

function SquawkAndAwe:SetBarBorderTexture(info, newValue)
	local newTexture		= media:Fetch("border", newValue)
	if newTexture then
		self.db.char.barborder	= newValue
		self.barBackdrop.edgeFile	= newTexture
  		self:RedrawFrames()
	elseif self.db.char.debug then
		self:Print("bar border texture not found. Trying to set "..self.db.char.barborder)
	end
end

-- Scripts
function SquawkAndAwe:ShowHideBars()
	self.db.char.barshow = not self.db.char.barshow
	if self.db.char.barshow then
		self.BaseFrame:EnableMouse(1);
		self.BaseFrame:SetBackdropColor(0, 0, 0, 1);
		self:RedrawFrames()
		self.db.char.barshow = true
		local k,i,v
		for k,v in pairs(SquawkAndAwe.frames) do
		    v:Show()
		end
	else
		self.BaseFrame:EnableMouse(0);
		self.BaseFrame:SetBackdropColor(1, 1, 1, 0);
		local k,v
		for i,v in ipairs(SquawkAndAwe.barFrames) do
		    v:Hide()
		end
	end
end

function SquawkAndAwe:FinishedMoving(var, frame)
	local point, relativeTo, relativePoint, xOffset, yOffset = frame:GetPoint();
	var.point			= point
	var.relativeTo		= relativeTo
	var.relativePoint	= relativePoint
	var.xOffset			= xOffset
	var.yOffset			= yOffset
end
